#!/usr/bin/env python3
"""Concurrent-session harness for bin/docket.  Stdlib only.

    python3 harness.py template            # build the seeded bare origin once (~10 s)
    python3 harness.py scenarios [names]   # run the scenario matrix (all by default)
    python3 harness.py random K STEPS SEED # K seeded random interleavings over 3 clones
    python3 harness.py forge               # (internal) the fake forge docket.toml points at

A "world" is: a bare origin (seeded from the real repo's origin/main, plus one commit that
points `open_pull_requests_command` at `harness.py forge`), a `gh` clone that performs GitHub's
side (squash merge, branch deletion), and N session clones.  Every commit is dated from the
world's clock through GIT_AUTHOR_DATE/GIT_COMMITTER_DATE and every docket read gets
--now/--today from the same clock, so nothing depends on wall time.  Pull-request state
(open / merged / closed) lives in a JSON file that `harness.py forge` (the command the seeded
docket.toml names as open_pull_requests_command) reads.

Invariants (fixed before the runs; each check in the scenarios names the one it tests):
  I1  claim arbitration: of two sessions claiming one item, at most one is told it holds it
      (exit 0), and nothing later revokes a claim that was confirmed first-visible.
  I2  claim visibility: exit 0 from `claim` means a fetched clone sees the claim (next does not
      offer the item, show names the holder).
  I3  agreement: flight, show and next name the same holder for an item.
  I4  landed is not held: once a PR squash-merged (and the reader fetched), flight/show/next do
      not report its items as held, and stranded does not list them.
  I5  next never offers an item that origin/main (as last fetched) records closed.
  I6  an open PR is not abandoned: stranded/flight never present an item on a branch with an
      open PR as lost work without saying a PR is open.
  I7  lease: a claim is live through exactly 7 days of silence and lapsed after; a lapsed claim
      is offered by next, named by flight/show, and takeable without --over.
  I8  arm: `behind N` iff origin/main has N commits HEAD lacks; `arm` only with nothing held,
      nothing outside the store, 0 behind; nothing arm-able is reported for a merged PR.
  I9  branch: a branch whose PR merged is told to restart, never to merge the base and push.
  I10 honesty: offline, --no-fetch, stale clone or forge down -> each read either answers
      correctly or says what it rests on (never a confident wrong answer).
  I11 check: 0 errors on a main that legitimate squash merges produced; a duplicate id errors.
"""

from __future__ import annotations

import json
import os
import random
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path

SIM = Path(__file__).resolve().parent
REAL = Path("/home/user/open-anesthesia-sim")
TEMPLATE = SIM / "template"
RUNS = SIM / "runs"
T0 = datetime(2026, 9, 25, 13, 0, tzinfo=UTC)
ID_RE = re.compile(r"\bPL-[0-9A-Z]{3,4}\b")


def sh(args, cwd, env=None, check=True, timeout=180):
    done = subprocess.run(
        args, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout, check=False
    )
    if check and done.returncode != 0:
        raise RuntimeError(f"{args} in {cwd} -> {done.returncode}\n{done.stdout}\n{done.stderr}")
    return done


def base_env(when: datetime) -> dict[str, str]:
    env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
    env.pop("CLAUDE_CODE_REMOTE_SESSION_ID", None)
    env.pop("GH_TOKEN", None)
    env.pop("GITHUB_TOKEN", None)
    env |= {
        "GIT_AUTHOR_DATE": when.isoformat(),
        "GIT_COMMITTER_DATE": when.isoformat(),
        "GIT_AUTHOR_NAME": "Sim",
        "GIT_AUTHOR_EMAIL": "sim@example.com",
        "GIT_COMMITTER_NAME": "Sim",
        "GIT_COMMITTER_EMAIL": "sim@example.com",
        "GIT_TERMINAL_PROMPT": "0",
    }
    return env


# --------------------------------------------------------------------------- template
def build_template() -> None:
    if TEMPLATE.exists():
        shutil.rmtree(TEMPLATE)
    TEMPLATE.mkdir(parents=True)
    # Read-only on the real repo: the commit its origin/main names.
    head = sh(["git", "rev-parse", "refs/remotes/origin/main"], REAL).stdout.strip()
    seed = TEMPLATE / "seed"
    sh(["git", "clone", "-q", "--no-local", str(REAL), str(seed)], SIM)
    sh(["git", "checkout", "-q", "-B", "main", head], seed)
    toml = seed / "docket.toml"
    text = toml.read_text()
    text = re.sub(
        r'open_pull_requests_command = ".*"',
        f'open_pull_requests_command = "python3 {SIM / "harness.py"} forge"',
        text,
    )
    toml.write_text(text)
    env = base_env(T0 - timedelta(hours=1))
    sh(["git", "commit", "-q", "-am", "sim: point open_pull_requests_command at the fake forge"],
       seed, env=env)
    origin = TEMPLATE / "origin.git"
    sh(["git", "init", "-q", "--bare", "-b", "main", str(origin)], SIM)
    sh(["git", "push", "-q", str(origin), "main:refs/heads/main"], seed)
    sh(["git", "push", "-q", str(origin), "--tags"], seed)
    shutil.rmtree(seed)
    print("template:", origin, head)


# --------------------------------------------------------------------------- world
@dataclass
class PR:
    number: int
    state: str  # open | merged | closed
    title: str


@dataclass
class Session:
    name: str
    root: Path
    branch: str = ""
    pushed: bool = False
    last_fetch: datetime | None = None


class World:
    def __init__(self, name: str, sessions: int = 3) -> None:
        self.name = name
        self.dir = RUNS / name
        if self.dir.exists():
            shutil.rmtree(self.dir)
        self.dir.mkdir(parents=True)
        self.origin = self.dir / "origin.git"
        shutil.copytree(TEMPLATE / "origin.git", self.origin, symlinks=True)
        self.t = T0
        self.prs: dict[str, PR] = {}
        self.next_pr = 1100
        self.forge_down = False
        self.pr_file = self.dir / "prs.json"
        self._save_prs()
        self.log_lines: list[str] = []
        self.gh = self._clone("gh")
        self.s: dict[str, Session] = {}
        for i in range(1, sessions + 1):
            name_i = f"s{i}"
            self.s[name_i] = Session(name_i, self._clone(name_i), last_fetch=self.t)

    # ---- plumbing
    def _clone(self, name: str) -> Path:
        root = self.dir / name
        sh(["git", "clone", "-q", str(self.origin), str(root)], self.dir)
        return root

    def tick(self, minutes: float = 1) -> None:
        self.t += timedelta(minutes=minutes)

    def env(self, session: str | None = None) -> dict[str, str]:
        env = base_env(self.t)
        env["SIM_PR_STATE"] = str(self.pr_file)
        if self.forge_down:
            env["SIM_FORGE_DOWN"] = "1"
        if session:
            env["CLAUDE_CODE_REMOTE_SESSION_ID"] = f"session_{self.name}_{session}"
        return env

    def _save_prs(self) -> None:
        self.pr_file.write_text(
            json.dumps({b: {"number": p.number, "state": p.state} for b, p in self.prs.items()})
        )

    def log(self, text: str) -> None:
        self.log_lines.append(f"[{self.t:%m-%d %H:%M}] {text}")

    def git(self, who: str, *args: str, check: bool = True):
        root = self.gh if who == "gh" else self.s[who].root
        return sh(["git", *args], root, env=self.env(who if who != "gh" else None), check=check)

    def docket(self, who: str, *args: str, now: bool = True) -> tuple[int, str]:
        root = self.s[who].root
        pre = ["--today", self.t.date().isoformat(), "--now", self.t.isoformat()] if now else []
        done = sh(["bin/docket", *pre, *args], root, env=self.env(who), check=False)
        out = done.stdout + (("\n[stderr]\n" + done.stderr) if done.stderr.strip() else "")
        return done.returncode, out

    # ---- session operations
    def start(self, who: str, branch: str) -> None:
        self.git(who, "checkout", "-q", "--no-track", "-b", branch, "origin/main")
        self.s[who].branch = branch
        self.log(f"{who}: start {branch} from its origin/main")

    def fetch(self, who: str) -> None:
        self.git(who, "fetch", "-q", "origin")
        self.s[who].last_fetch = self.t
        self.log(f"{who}: fetch")

    def capture(self, who: str, *titles: str, commit: bool = True) -> list[str]:
        code, out = self.docket(who, "new", *titles)
        if code != 0:
            raise RuntimeError(out)
        ids = []
        for line in out.splitlines():
            m = re.match(r"\s*(?:captured\s+)?(PL-[0-9A-Z]{4})\b", line)
            if m and m.group(1) not in ids:
                ids.append(m.group(1))
        ids = ids[: len(titles)]
        if commit:
            self.git(who, "add", "-A", "docs/items")
            self.git(who, "commit", "-q", "-m", f"{', '.join(ids)}: capture\n\n{out.strip()[:200]}")
        self.log(f"{who}: capture {ids}")
        return ids

    def claim(self, who: str, *ids: str, no_fetch: bool = False, over: str = "",
              reason: str = "") -> tuple[int, str]:
        extra = ["--no-fetch"] if no_fetch else []
        if over:
            extra += ["--over", over, "--reason", reason or "sim takeover"]
        code, out = self.docket(who, "claim", *ids, *extra)
        if code in (0, 3) and not no_fetch:
            self.s[who].last_fetch = self.t
        if "and pushed" in out:
            self.s[who].pushed = True
        self.log(f"{who}: claim {ids} -> {code}")
        return code, out

    def work(self, who: str, item: str, path: str | None = None) -> None:
        path = path or f"sim-work/{self.s[who].branch.split('/')[-1]}.txt"
        target = self.s[who].root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a") as handle:
            handle.write(f"# {item} work at {self.t.isoformat()}\n")
        self.git(who, "add", path)
        self.git(who, "commit", "-q", "-m", f"{item}: work")
        self.log(f"{who}: work {item} ({path})")

    def item_path(self, who: str, item: str) -> Path:
        found = list((self.s[who].root / "docs/items").glob(f"{item}-*.md"))
        if not found:
            found = list((self.s[who].root / "docs/items").glob(f"{item}.md"))
        return found[0]

    def set_status(self, who: str, item: str, status: str, subject: str | None = None) -> None:
        path = self.item_path(who, item)
        text = path.read_text()
        text = re.sub(r"^status: .*$", f"status: {status}", text, count=1, flags=re.M)
        if status in ("done", "dropped") and not re.search(r"^closed:", text, re.M):
            text = re.sub(r"^(status: .*)$", rf"\1\nclosed: {self.t.date()}", text, count=1,
                          flags=re.M)
        path.write_text(text)
        self.git(who, "add", "-A", "docs/items")
        self.git(who, "commit", "-q", "-m", subject or f"{item}: {status}")
        self.log(f"{who}: {item} -> {status}")

    def edit_item_body(self, who: str, item: str, note: str) -> None:
        path = self.item_path(who, item)
        path.write_text(path.read_text() + f"\n{note}\n")
        self.git(who, "add", "-A", "docs/items")
        self.git(who, "commit", "-q", "-m", f"{item}: note")
        self.log(f"{who}: note on {item}")

    def push(self, who: str) -> None:
        self.git(who, "push", "-q", "-u", "origin", "HEAD")
        self.s[who].pushed = True
        self.log(f"{who}: push {self.s[who].branch}")

    def merge_main_in(self, who: str) -> None:
        self.fetch(who)
        self.git(who, "merge", "-q", "--no-edit", "origin/main")
        self.log(f"{who}: merge origin/main in")

    def open_pr(self, who: str, title: str | None = None) -> PR:
        branch = self.s[who].branch
        if title is None:
            title = self.git(who, "log", "-1", "--format=%s", "HEAD").stdout.strip()
        pr = PR(self.next_pr, "open", title)
        self.next_pr += 1
        self.prs[branch] = pr
        self._save_prs()
        self.log(f"{who}: open PR #{pr.number} '{title}' on {branch}")
        return pr

    # ---- GitHub's side
    def squash_merge(self, branch: str, title: str | None = None) -> str:
        pr = self.prs[branch]
        title = title or pr.title
        self.git("gh", "fetch", "-q", "origin")
        self.git("gh", "checkout", "-q", "-B", "main", "origin/main")
        merged = self.git("gh", "merge", "--squash", f"origin/{branch}", check=False)
        if merged.returncode != 0:
            raise RuntimeError(f"squash of {branch} conflicts: {merged.stdout}{merged.stderr}")
        self.git("gh", "commit", "-q", "--allow-empty", "-m", f"{title} (#{pr.number})")
        self.git("gh", "push", "-q", "origin", "main")
        pr.state = "merged"
        self._save_prs()
        sha = self.git("gh", "rev-parse", "HEAD").stdout.strip()
        self.log(f"gh: squash-merge #{pr.number} {branch} -> main {sha[:10]}")
        return sha

    def commit_on_main(self, subject: str, mutate) -> str:
        """A direct change landing on main (another PR's squash, simplified)."""
        self.git("gh", "fetch", "-q", "origin")
        self.git("gh", "checkout", "-q", "-B", "main", "origin/main")
        mutate(self.gh)
        self.git("gh", "add", "-A")
        self.git("gh", "commit", "-q", "-m", subject)
        self.git("gh", "push", "-q", "origin", "main")
        self.log(f"gh: main <- {subject}")
        return self.git("gh", "rev-parse", "HEAD").stdout.strip()

    def close_pr(self, branch: str) -> None:
        self.prs[branch].state = "closed"
        self._save_prs()
        self.log(f"gh: close PR on {branch} unmerged")

    def delete_branch(self, branch: str) -> None:
        self.git("gh", "push", "-q", "origin", "--delete", branch)
        self.log(f"gh: delete {branch}")

    def unreachable(self, who: str, down: bool = True) -> None:
        url = str(self.dir / "nowhere.git") if down else str(self.origin)
        self.git(who, "remote", "set-url", "origin", url)
        self.log(f"{who}: origin {'unreachable' if down else 'restored'}")

    # ---- reads
    def flight(self, who: str, *extra: str) -> tuple[int, str]:
        return self.docket(who, "flight", *extra)

    def next_ids(self, who: str) -> tuple[list[str], list[str], str]:
        code, out = self.docket(who, "next", "--limit", "400")
        offered, excluded = [], []
        for line in out.splitlines():
            m = re.match(r"\s+\d+\. P\d (PL-[0-9A-Z]+) ", line)
            if m:
                offered.append(m.group(1))
            if line.startswith("Excluded, already in flight:"):
                excluded = ID_RE.findall(line)
        return offered, excluded, out

    def add_session(self, name: str) -> None:
        self.s[name] = Session(name, self._clone(name), last_fetch=self.t)
        self.log(f"{name}: fresh clone")


# --------------------------------------------------------------------------- parsers
FLIGHT_ROW = re.compile(r"^(PL-[0-9A-Z]+)  (\S+)\s+(live|lapsed|released)\s+(.*)$")


def flight_rows(out: str) -> list[tuple[str, str, str, str]]:
    """(id, ref, state, rest) for every table row, live section and lapsed section alike."""
    rows = []
    for line in out.splitlines():
        m = FLIGHT_ROW.match(line)
        if m:
            rows.append((m.group(1), m.group(2), m.group(3), m.group(4)))
    return rows


def flight_live(out: str) -> dict[str, list[str]]:
    held: dict[str, list[str]] = {}
    for item, ref, state, _ in flight_rows(out):
        if state == "live":
            held.setdefault(item, []).append(ref)
    return held


def flight_settled(out: str) -> str:
    m = re.search(r"^On \d+ branch(?:es)? every item.*?(?=\n\n\S|\Z)", out, re.M | re.S)
    return m.group(0) if m else ""


def show_holder(out: str) -> str:
    m = re.search(r"^\s+holds it\s+(\S+)", out, re.M)
    if m:
        return m.group(1)
    m = re.search(r"IN FLIGHT on (?:this branch \()?(\S+?)\)?(?:,| -|$)", out, re.M)
    return m.group(1) if m else ""


def stranded_ids(out: str) -> list[str]:
    """Ids the first section (items only on a branch) names."""
    found = []
    lines = out.splitlines()
    for i, line in enumerate(lines):
        m = re.match(r"^(PL-[0-9A-Z]+)  ", line)
        if m and i + 1 < len(lines) and "only on:" in lines[i + 1]:
            found.append(m.group(1))
    return found


def stranded_ahead(out: str) -> list[str]:
    ids = []
    m = re.search(r"ahead of.*?(?=\n\n[A-Z]|\Z)", out, re.S)
    if m:
        ids = ID_RE.findall(m.group(0))
    return ids


def orphan_clean(out: str) -> bool:
    return "No branch carries work its own pull request left behind" in out


# --------------------------------------------------------------------------- results
@dataclass
class Finding:
    scenario: str
    command: str
    verdict: str  # pass | VIOLATION | note
    detail: str = ""
    cls: str = ""  # confident-wrong | noisy-correct | crash | said-unknown


class Recorder:
    def __init__(self) -> None:
        self.findings: list[Finding] = []

    def check(self, scenario, command, ok, detail="", cls="confident-wrong"):
        f = Finding(scenario, command, "pass" if ok else "VIOLATION", detail if not ok else "",
                    "" if ok else cls)
        self.findings.append(f)
        mark = "ok  " if ok else "FAIL"
        print(f"  [{mark}] {scenario} {command}: {detail if not ok else ''}")
        return ok

    def note(self, scenario, command, detail):
        self.findings.append(Finding(scenario, command, "note", detail))
        print(f"  [note] {scenario} {command}: {detail}")


REC = Recorder()
DUMP = SIM / "runs" / "outputs"


def dump(w: World, label: str, text: str) -> None:
    DUMP.mkdir(parents=True, exist_ok=True)
    with (DUMP / f"{w.name}.txt").open("a") as handle:
        handle.write(f"\n===== {label} @ {w.t.isoformat()}\n{text}\n")


def run(w: World, who: str, *args: str) -> tuple[int, str]:
    code, out = w.docket(who, *args)
    dump(w, f"{who}$ docket {' '.join(args)} -> {code}", out)
    return code, out


# Items from the seed that `next` offers at baseline (ready, unblocked).
X, Y, Z = "PL-FX5Q", "PL-QHCW", "PL-CWD4"


def rev_count(w: World, who: str, spec: str) -> int:
    return int(w.git(who, "rev-list", "--count", spec).stdout.strip())


# --------------------------------------------------------------------------- scenarios
def scen_a1():
    """Two sessions claim the same item a minute apart; the second fetched first."""
    w = World("a1", 3)
    w.start("s1", "claude/alpha-a1a1a1"); w.start("s2", "claude/beta-b2b2b2")
    w.tick(); c1, o1 = w.claim("s1", X); dump(w, "s1 claim", o1)
    w.tick(0.5); c2, o2 = w.claim("s2", X); dump(w, "s2 claim", o2)
    REC.check("a1", "claim", (c1, c2) == (0, 3), f"exit codes {(c1, c2)}")
    w.fetch("s3")
    _agree(w, "a1", "s3", X, "claude/alpha-a1a1a1")
    return w


def scen_a2():
    """Second claimer did not fetch (--no-fetch, stale view), pushes, then reads back."""
    w = World("a2", 3)
    w.start("s1", "claude/alpha-a2a2a2"); w.start("s2", "claude/beta-b3b3b3")
    w.tick(); c1, o1 = w.claim("s1", X); dump(w, "s1 claim", o1)
    w.tick(0.5); c2, o2 = w.claim("s2", X, no_fetch=True); dump(w, "s2 claim", o2)
    REC.check("a2", "claim", c1 == 0 and c2 == 3, f"exit codes {(c1, c2)}; s2 said: {o2.strip()[:160]}")
    w.fetch("s3")
    _agree(w, "a2", "s3", X, "claude/alpha-a2a2a2")
    return w


def scen_a3():
    """Retroactive order: s2 writes its claim first but the push fails; s1 claims and is
    told it holds; s2 retries later.  s1 was confirmed first-visible."""
    w = World("a3", 3)
    w.start("s1", "claude/alpha-a3a3a3"); w.start("s2", "claude/beta-b4b4b4")
    w.tick()
    w.unreachable("s2")
    c2, o2 = w.claim("s2", X, no_fetch=True); dump(w, "s2 claim (push fails)", o2)
    w.unreachable("s2", down=False)
    w.tick(1); c1, o1 = w.claim("s1", X); dump(w, "s1 claim", o1)
    w.tick(1); c2b, o2b = w.claim("s2", X); dump(w, "s2 claim retry", o2b)
    REC.check("a3", "claim", not (c1 == 0 and c2b == 0),
              f"s2 first try exit {c2} (local only); s1 exit {c1} (told it holds X); s2 retry exit {c2b} "
              f"- both sessions told they hold {X}", "confident-wrong")
    w.fetch("s3")
    code, out = run(w, "s3", "show", X)
    REC.check("a3", "show", show_holder(out).endswith("alpha-a3a3a3"),
              f"s3 show names {show_holder(out)} as holder though s1 was confirmed first", "confident-wrong")
    w.fetch("s1")
    code, out = run(w, "s1", "show", X)
    REC.check("a3", "show(s1 own)", "claimed by another" not in out and show_holder(out).endswith("alpha-a3a3a3"),
              f"s1 later reads: {[l.strip() for l in out.splitlines() if 'yields' in l or 'holds it' in l]}", "confident-wrong")
    return w


def _agree(w: World, scen: str, who: str, item: str, branch: str) -> None:
    """flight, show and next in `who` all say `branch` holds `item`."""
    _, fo = run(w, who, "flight")
    live = flight_live(fo)
    REC.check(scen, "flight", any(r.endswith(branch) for r in live.get(item, [])) and len(live.get(item, [])) == 1,
              f"flight live rows for {item}: {live.get(item)}")
    _, so = run(w, who, "show", item)
    REC.check(scen, "show", show_holder(so).endswith(branch), f"show holder '{show_holder(so)}'")
    offered, excluded, _ = w.next_ids(who)
    REC.check(scen, "next", item not in offered and item in excluded,
              f"offered={item in offered} excluded={item in excluded}")


def _stale_note(out: str) -> bool:
    return bool(re.search(r"Nothing refreshed|last fetch|not fetched|since the last fetch|behind origin/main", out))


def scen_b():
    """A's PR squash-merges (item closed, branch auto-deleted) while B's clone is stale."""
    w = World("b", 3)
    w.fetch("s2")  # s2's last fetch: before anything happened
    w.start("s1", "claude/alpha-bbbb01"); w.tick()
    w.claim("s1", X); w.work("s1", X); w.tick(); w.set_status("s1", X, "done", f"{X}: close out")
    w.push("s1"); w.open_pr("s1", f"{X}: the work"); w.tick(5)
    w.squash_merge("claude/alpha-bbbb01"); w.delete_branch("claude/alpha-bbbb01"); w.tick(2)
    # s2 never fetched since.
    w.start("s2", "claude/beta-bbbb02")
    offered, excluded, nout = w.next_ids("s2"); dump(w, "s2 next (stale)", nout)
    REC.check("b", "next(stale)", X not in offered,
              f"stale clone offers {X}, which merged done at {w.t - timedelta(minutes=2):%H:%M}; staleness note printed: "
              f"{_stale_note(nout)}", "confident-wrong")
    _, so = run(w, "s2", "show", X)
    REC.check("b", "show(stale)", "done" in so.splitlines()[1] or "fetch" in so.lower() or "IN FLIGHT" in so,
              f"stale show says status line '{so.splitlines()[1].strip()}' with no in-flight mark and no staleness note",
              "confident-wrong")
    c, o = w.claim("s2", X); dump(w, "s2 claim after merge", o)
    REC.check("b", "claim", c != 0 and "defect in docket" not in o and "pushed" not in o,
              f"claim on an item main closed -> exit {c}: {o.strip()[:300]}", "confident-wrong")
    # a fresh session now
    w.add_session("s4")
    _, fo = run(w, "s4", "flight")
    REC.check("b", "flight(fresh)", X not in flight_live(fo), f"fresh flight rows {flight_live(fo)}")
    return w


def scen_c(close: bool = True, delete: bool = False, name: str = "c"):
    """Branch merged main in, then squash-merged; branch left (or deleted)."""
    w = World(name, 3)
    br = f"claude/alpha-{name}c0c0"
    w.start("s1", br); w.tick()
    w.claim("s1", X); w.work("s1", X); w.tick(10)
    w.commit_on_main("PL-0000: someone else's change (#1050)",
                     lambda root: (root / "sim-other.txt").write_text("other\n"))
    w.tick(); w.merge_main_in("s1"); w.work("s1", X); w.tick()
    if close:
        w.set_status("s1", X, "done", f"{X}: close out")
    w.push("s1"); w.open_pr("s1", f"{X}: the work"); w.tick(5)
    w.fetch("s3")  # s3 holds the branch ref from before the merge; it never prunes
    w.squash_merge(br)
    if delete:
        w.delete_branch(br)
    w.tick(2)
    w.fetch("s2")
    w.fetch("s3")
    has_ref = w.git("s3", "rev-parse", "--verify", "--quiet", f"refs/remotes/origin/{br}", check=False).returncode == 0
    _, f2 = run(w, "s2", "flight"); _, f3 = run(w, "s3", "flight")
    _, t2 = run(w, "s2", "stranded", "--no-fetch"); _, t3 = run(w, "s3", "stranded", "--no-fetch")
    REC.check(name, "flight/stranded(pruned vs stale ref)",
              flight_live(f2) == flight_live(f3) and stranded_ids(t2) == stranded_ids(t3) and orphan_clean(t3),
              f"s3 keeps ref={has_ref}; flight {flight_live(f2)} vs {flight_live(f3)}; stranded {stranded_ids(t2)} vs {stranded_ids(t3)}")
    _, fo = run(w, "s2", "flight")
    REC.check(name, "flight", X not in flight_live(fo) and br not in flight_settled(fo),
              f"flight after squash: live={flight_live(fo).get(X)} settled-section-mentions-branch={br in flight_settled(fo)}")
    offered, excluded, nout = w.next_ids("s2")
    if close:
        behind = rev_count(w, "s2", "HEAD..origin/main")
        REC.check(name, "next", X not in offered, f"fetched clone whose working tree is {behind} behind origin/main offers {X}, "
                  f"which origin/main records done; staleness note={_stale_note(nout)}", "confident-wrong")
        _, so = run(w, "s2", "show", X)
        REC.check(name, "show(behind)", "done" in so.splitlines()[1] or _stale_note(so),
                  f"show says '{so.splitlines()[1].strip()}' with no note", "confident-wrong")
        w.git("s2", "merge", "-q", "--ff-only", "origin/main")
        offered2, _, _ = w.next_ids("s2")
        REC.check(name, "next(after ff)", X not in offered2, f"offered after ff={X in offered2}")
    else:
        REC.note(name, "next", f"item left open on main after its work merged: offered={X in offered} excluded={X in excluded}")
    _, so = run(w, "s2", "show", X)
    REC.check(name, "show", "IN FLIGHT" not in so, f"show: {[l for l in so.splitlines() if 'FLIGHT' in l]}")
    _, st = run(w, "s2", "stranded", "--no-fetch")
    REC.check(name, "stranded", not stranded_ids(st) and orphan_clean(st), f"stranded ids {stranded_ids(st)} orphan_clean={orphan_clean(st)}")
    code, ck = run(w, "s2", "check")
    errs = re.search(r"(\d+) errors?", ck)
    REC.check(name, "check(main)", errs and errs.group(1) == "0", f"check on main after merge: {ck.splitlines()[0]}; "
              + " | ".join(l.strip() for l in ck.splitlines() if l.startswith("  PL-"))[:300], "noisy-correct")
    # The merged branch's own session asks where it stands.
    w.fetch("s1")
    _, bo = run(w, "s1", "branch", "--no-fetch")
    REC.check(name, "branch(s1)", "merged" in bo.lower() or "restart" in bo.lower() or "checkout -B" in bo,
              f"branch on merged branch: {bo.strip().splitlines()[0:3]}", "confident-wrong")
    ca, ao = run(w, "s1", "arm", "--no-fetch")
    REC.check(name, "arm(s1)", not ao.startswith(("arm", "behind")), f"arm on a merged PR's branch: {ao.splitlines()[0]}", "noisy-correct")
    return w


def scen_e():
    """PR closed unmerged; session gone."""
    w = World("e", 3)
    br = "claude/alpha-eeee01"
    w.start("s1", br); w.tick()
    cap = w.capture("s1", "A sim capture on a branch that will be closed")[0]
    w.claim("s1", X); w.work("s1", X); w.push("s1"); w.open_pr("s1"); w.tick(30)
    w.close_pr(br); w.tick(30)
    w.fetch("s2")
    _, fo = run(w, "s2", "flight")
    rows = [r for r in flight_rows(fo) if r[0] == X]
    REC.check("e", "flight", rows and "no pull request open" in rows[0][3], f"rows {rows}", "said-unknown")
    REC.note("e", "flight", "closed-unmerged reads exactly like 'no PR yet' (forge seam lists open PRs only); item stays excluded from next for the 7-day lease")
    offered, excluded, _ = w.next_ids("s2")
    REC.note("e", "next", f"{X} offered={X in offered} excluded={X in excluded} (held by a branch whose PR was closed unmerged)")
    _, st = run(w, "s2", "stranded", "--no-fetch")
    REC.check("e", "stranded", cap in stranded_ids(st), f"capture on closed branch listed={cap in stranded_ids(st)}")
    return w


def scen_f():
    """Captures-only branch: pushed, PR open, armed, squash-merged, session continues on it."""
    w = World("f", 3)
    br = "claude/capture-ffff01"
    w.start("s1", br); w.tick()
    cap = w.capture("s1", "A sim capture that rides a captures-only branch")[0]
    w.push("s1"); w.open_pr("s1"); w.tick()
    ca, ao = run(w, "s1", "arm")
    REC.check("f", "arm(open)", ao.startswith("arm"), ao.splitlines()[0])
    w.fetch("s2")
    _, st = run(w, "s2", "stranded", "--no-fetch")
    block = st.split(cap, 1)[1].split("\n\n", 1)[0] if cap in st else ""
    REC.check("f", "stranded(PR open)", cap not in stranded_ids(st) or "pull request" in block,
              f"{cap} reported only-on-branch with a recover line while PR #{w.prs[br].number} is open and armed", "noisy-correct")
    w.tick(3); w.squash_merge(br); w.tick(1)
    w.fetch("s1")
    _, bo = run(w, "s1", "branch", "--no-fetch")
    REC.check("f", "branch(after merge)", "git merge origin/main" not in bo,
              f"merged captures-only branch told: {' / '.join(l.strip() for l in bo.strip().splitlines()[:3])}", "confident-wrong")
    ca, ao = run(w, "s1", "arm", "--no-fetch")
    REC.check("f", "arm(after merge)", not ao.startswith(("arm", "behind")), ao.splitlines()[0], "noisy-correct")
    # The session follows the advice and keeps capturing on the same branch.
    w.merge_main_in("s1"); w.tick()
    cap2 = w.capture("s1", "A second capture pushed after the merge")[0]
    ca, ao = run(w, "s1", "arm", "--no-fetch")
    w.push("s1"); w.tick()
    REC.note("f", "arm(post-merge push)", f"after merge-in + new capture, arm says: {ao.splitlines()[0][:120]} (PR #{w.prs[br].number} is merged)")
    w.fetch("s2")
    _, st = run(w, "s2", "stranded", "--no-fetch")
    REC.check("f", "stranded(post-merge capture)", cap2 in stranded_ids(st), f"post-merge capture listed={cap2 in stranded_ids(st)}")
    return w


def scen_g():
    """Item filed on a branch, squash-merged, then triaged+renamed on main; branch kept."""
    w = World("g", 3)
    br = "claude/capture-gggg01"
    w.start("s1", br); w.tick()
    cap = w.capture("s1", "A sim capture that main will triage and rename")[0]
    w.push("s1"); w.open_pr("s1"); w.tick(); w.squash_merge(br); w.tick()

    def triage(root: Path) -> None:
        path = next((root / "docs/items").glob(f"{cap}-*.md"))
        text = path.read_text().replace("status: untriaged", "status: ready\npriority: P3\neffort: S")
        text = re.sub(r"^title: .*$", "title: A renamed sim capture", text, count=1, flags=re.M)
        new = path.with_name(f"{cap}-a-renamed-sim-capture.md")
        path.unlink(); new.write_text(text + "\nTriaged on main.\n")
    w.commit_on_main(f"{cap}: triage (#1060)", triage); w.tick()
    w.fetch("s2")
    _, st = run(w, "s2", "stranded", "--no-fetch")
    REC.check("g", "stranded", cap not in stranded_ids(st) and cap not in stranded_ahead(st),
              f"stranded lists={cap in stranded_ids(st)} ahead={cap in stranded_ahead(st)}")
    _, fo = run(w, "s2", "flight")
    REC.check("g", "flight", cap not in flight_live(fo), f"flight {flight_live(fo)}")
    # the capturing session edits its (old-name) copy after the merge
    w.edit_item_body("s1", cap, "A late note written on the merged branch."); w.push("s1"); w.tick()
    w.fetch("s2")
    _, st = run(w, "s2", "stranded", "--no-fetch")
    REC.check("g", "stranded(late note)", cap in st, f"late note on renamed item reported={cap in st}")
    return w


def scen_h():
    """A claim older than the 7-day lease."""
    w = World("h", 3)
    br = "claude/alpha-hhhh01"
    w.start("s1", br); w.tick()
    w.claim("s1", X)
    w.t += timedelta(days=7)  # exactly the term: still live
    w.fetch("s2")
    offered, excluded, _ = w.next_ids("s2")
    REC.check("h", "next(at term)", X not in offered, f"offered at exactly 7d: {X in offered}")
    w.tick(2)
    offered, excluded, _ = w.next_ids("s2")
    REC.check("h", "next(past term)", X in offered, f"offered past lease: {X in offered}")
    _, fo = run(w, "s2", "flight")
    lap = [r for r in flight_rows(fo) if r[0] == X]
    REC.check("h", "flight(past term)", lap and lap[0][2] == "lapsed", f"rows {lap}")
    _, so = run(w, "s2", "show", X)
    REC.check("h", "show(past term)", "lapsed" in so, "show does not mention the lapsed claim")
    w.start("s2", "claude/beta-hhhh02")
    c2, o2 = w.claim("s2", X); dump(w, "s2 claim", o2)
    REC.check("h", "claim(after lapse)", c2 == 0, f"exit {c2}: {o2.strip()[:200]}")
    # s1 comes back and commits work; its claim does not revive
    w.tick(); w.work("s1", X); w.push("s1")
    ca, ao = run(w, "s1", "arm", "--no-fetch")
    REC.check("h", "arm(s1 lapsed)", ao.startswith("hold"), ao.splitlines()[0])
    _, so = run(w, "s1", "show", X)
    REC.note("h", "show(s1 returns)", " / ".join(l.strip() for l in so.splitlines() if "FLIGHT" in l or "lapsed" in l)[:300])
    return w


def scen_i():
    """A claim that never reached the remote."""
    w = World("i", 3)
    # i1: branch already on the remote (a captures-only push went first)
    br = "claude/alpha-iiii01"
    w.start("s1", br); w.tick()
    w.capture("s1", "A sim capture pushed before the claim"); w.push("s1"); w.open_pr("s1"); w.tick()
    c1, o1 = w.claim("s1", X); dump(w, "s1 claim on pushed branch", o1)
    w.fetch("s2")
    offered, excluded, _ = w.next_ids("s2")
    REC.check("i", "claim(branch already pushed)", c1 != 0 or X not in offered,
              f"claim exit {c1} ('{o1.strip()[:110]}...'), yet s2 next offers {X}={X in offered}", "confident-wrong")
    ca, ao = run(w, "s1", "arm", "--no-fetch")
    REC.check("i", "arm(unpushed claim)", ao.startswith("hold"), ao.splitlines()[0])
    # i2: push fails
    w.start("s3", "claude/gamma-iiii03")
    w.unreachable("s3")
    c3, o3 = w.claim("s3", Y, no_fetch=True); dump(w, "s3 claim push fails", o3)
    REC.check("i", "claim(push fails)", c3 == 4, f"exit {c3}")
    w.unreachable("s3", down=False)
    return w


def scen_i2():
    """The realistic route to a3: a claim on an already-pushed branch, pushed by hand later."""
    w = World("i2", 3)
    b1, b2 = "claude/alpha-i2i2i1", "claude/beta-i2i2i2"
    w.start("s1", b1); w.tick()
    w.capture("s1", "A sim capture pushed before the claim"); w.push("s1"); w.open_pr("s1"); w.tick()
    c1, o1 = w.claim("s1", X); dump(w, "s1 claim (not pushed)", o1)
    w.tick(5)
    w.start("s2", b2)
    c2, o2 = w.claim("s2", X); dump(w, "s2 claim", o2)
    w.tick(5)
    w.push("s1")  # s1 follows its claim's advice: "then push"
    w.tick()
    w.fetch("s3")
    _, so = run(w, "s3", "show", X)
    _, so2 = run(w, "s2", "show", X)
    REC.check("i2", "claim+show", not (c1 == 0 and c2 == 0 and show_holder(so).endswith(b1)),
              f"s1 claim exit {c1} (not pushed), s2 claim exit {c2} (pushed, confirmed first); after s1 pushes, "
              f"show names {show_holder(so)}; s2 now reads: "
              f"{[l.strip() for l in so2.splitlines() if 'yields' in l.lower()][:2]}", "confident-wrong")
    return w


def scen_j():
    """Two captures in parallel clones, same title, same instant."""
    w = World("j", 3)
    w.start("s1", "claude/cap-jjjj01"); w.start("s2", "claude/cap-jjjj02")
    a = w.capture("s1", "Identical title captured twice")[0]
    b = w.capture("s2", "Identical title captured twice")[0]
    REC.check("j", "new(ids)", a != b, f"{a} vs {b}")
    w.push("s1"); w.push("s2"); w.open_pr("s1"); w.open_pr("s2"); w.tick()
    w.squash_merge("claude/cap-jjjj01"); w.tick(); w.squash_merge("claude/cap-jjjj02"); w.tick()
    w.fetch("s3")
    code, ck = run(w, "s3", "check")
    errs = re.search(r"(\d+) errors?", ck)
    REC.check("j", "check(both merged)", errs and errs.group(1) == "0", ck.splitlines()[0])
    # forced id collision: s2 writes a different item under s1's id (what a 1-in-923,521 draw does)
    w.start("s1", "claude/cap-jjjj11"); w.start("s2", "claude/cap-jjjj12")
    c = w.capture("s1", "First item under a colliding id")[0]
    src = w.item_path("s1", c).read_text().replace("First item under a colliding id", "Second item under a colliding id")
    (w.s["s2"].root / "docs/items" / f"{c}-second-item-under-a-colliding-id.md").write_text(src)
    w.git("s2", "add", "-A"); w.git("s2", "commit", "-q", "-m", f"{c}: capture")
    w.push("s1"); w.push("s2"); w.open_pr("s1"); w.open_pr("s2"); w.tick()
    w.squash_merge("claude/cap-jjjj11"); w.tick()
    w.fetch("s3")
    _, st = run(w, "s3", "stranded", "--no-fetch")
    REC.check("j", "stranded(id collision)", c in st, f"the colliding item on claude/cap-jjjj12 (not on main) is reported={c in st}", "confident-wrong")
    w.squash_merge("claude/cap-jjjj12"); w.tick(); w.fetch("s3")
    w.git("s3", "checkout", "-q", "--detach", "origin/main")
    code, ck = run(w, "s3", "check")
    errs = re.search(r"(\d+) errors?", ck)
    REC.check("j", "check(duplicate id on main)", errs and errs.group(1) != "0", ck.splitlines()[0], "confident-wrong")
    return w


def scen_k():
    """Offline: origin unreachable after a merge the clone has not seen; and --no-fetch."""
    w = World("k", 3)
    w.start("s1", "claude/alpha-kkkk01"); w.tick()
    cap = w.capture("s1", "A sim capture that merges while s2 is offline")[0]
    w.claim("s1", X); w.work("s1", X); w.push("s1"); w.open_pr("s1", f"{X}, {cap}: the work"); w.tick()
    w.start("s2", "claude/beta-kkkk02")
    w.fetch("s2")  # s2 sees s1's branch (and its capture) before the merge
    w.tick(); w.squash_merge("claude/alpha-kkkk01"); w.tick()
    w.unreachable("s2")
    code, st = run(w, "s2", "stranded")
    REC.check("k", "stranded(unreachable)", cap not in stranded_ids(st) or _stale_note(st),
              f"fetch failed silently; {cap} (merged as #{w.prs['claude/alpha-kkkk01'].number}) reported only on a branch "
              f"with a `recover: git checkout` line and no 'not refreshed' caveat", "confident-wrong")
    code, bo = run(w, "s2", "branch")
    REC.check("k", "branch(unreachable)", "current with" not in bo or _stale_note(bo),
              f"after a failed fetch, with origin/main 1 commit ahead on the remote: '{bo.strip().splitlines()[0][:100]}'", "confident-wrong")
    code, ao = run(w, "s2", "arm")
    REC.check("k", "arm(unreachable)", ao.startswith("unknown"), ao.splitlines()[0][:140])
    c, o = w.claim("s2", Y)
    REC.check("k", "claim(unreachable)", c == 1, f"exit {c}")
    _, fo = run(w, "s2", "flight")
    REC.check("k", "flight(unreachable)", X not in flight_live(fo) or _stale_note(fo),
              f"flight reports {X} live on s1's branch (merged) with no note that its refs predate the last fetch", "confident-wrong")
    offered, excluded, nout = w.next_ids("s2")
    REC.note("k", "next(unreachable)", f"{X} excluded as in flight (merged; conservative), note={_stale_note(nout)}")
    w.unreachable("s2", down=False)
    code, st = run(w, "s2", "stranded", "--no-fetch")
    REC.check("k", "stranded(--no-fetch, stale)", "Nothing refreshed" in st, "no caveat line")
    return w


def scen_l_postmerge():
    """#284: a commit pushed to a branch after its PR squash-merged."""
    w = World("l1", 3)
    br = "claude/alpha-llll01"
    w.start("s1", br); w.tick()
    w.claim("s1", X); w.work("s1", X); w.set_status("s1", X, "done")
    w.push("s1"); w.open_pr("s1", f"{X}: the work"); w.tick(); w.squash_merge(br); w.tick()
    w.work("s1", X, "sim-work/after-merge.txt"); w.push("s1"); w.tick()
    w.fetch("s2")
    _, st = run(w, "s2", "stranded", "--no-fetch")
    REC.check("l1", "stranded(orphaned)", not orphan_clean(st), "commit pushed after merge not reported")
    _, fo = run(w, "s2", "flight")
    REC.check("l1", "flight", X not in flight_live(fo), f"flight live {flight_live(fo)}")
    return w


def scen_l_settled():
    """PL-Q664/PL-7TVT: branch closed its items; with and without an open PR."""
    w = World("l2", 3)
    br = "claude/alpha-l2l2l2"
    w.start("s1", br); w.tick()
    w.claim("s1", X); w.work("s1", X); w.set_status("s1", X, "done"); w.push("s1"); w.tick()
    w.fetch("s2")
    _, fo = run(w, "s2", "flight")
    REC.check("l2", "flight(no PR)", br in flight_settled(fo), "finished branch with no PR not in settled section")
    w.open_pr("s1", f"{X}: the work")
    _, fo = run(w, "s2", "flight")
    REC.check("l2", "flight(PR open)", br not in flight_settled(fo) and "#" in fo, "finished branch with PR open listed as settled")
    w.forge_down = True
    _, fo = run(w, "s2", "flight")
    REC.check("l2", "flight(forge down)", "could not be read" in fo, "forge failure not stated", "confident-wrong")
    w.forge_down = False
    offered, excluded, _ = w.next_ids("s2")
    REC.check("l2", "next", X not in offered, f"offered {X in offered}")
    return w


def scen_l_record():
    """#372: a branch's `docket record` commit converges with main's identical record write."""
    w = World("l3", 3)
    b1, b2 = "claude/alpha-l3l3l1", "claude/beta-l3l3l2"
    w.start("s1", b1); w.tick(); w.claim("s1", Z); w.work("s1", Z); w.push("s1"); w.open_pr("s1", f"{Z}: the work")
    w.start("s2", b2); w.tick(); w.claim("s2", X); w.work("s2", X); w.set_status("s2", X, "done")
    w.push("s2"); w.open_pr("s2", f"{X}: the work"); w.tick(); w.squash_merge(b2); w.tick()
    w.merge_main_in("s1")
    code, out = w.docket("s1", "record"); dump(w, "s1 record", out)
    w.git("s1", "add", "-A", "docs/items"); w.git("s1", "commit", "-q", "-m", f"{X}: record its pull request")
    w.push("s1"); w.tick()

    def record_on_main(root: Path) -> None:
        sh(["bin/docket", "--today", w.t.date().isoformat(), "record"], root, env=w.env())
    w.commit_on_main(f"{X}: record its pull request (#1190)", record_on_main); w.tick()
    w.fetch("s3")
    _, st = run(w, "s3", "stranded", "--no-fetch")
    REC.check("l3", "stranded(orphaned)", orphan_clean(st), "live branch with an open PR reported as having left work behind")
    _, fo = run(w, "s3", "flight")
    REC.check("l3", "flight", any(r.endswith(b1) for r in flight_live(fo).get(Z, [])), f"live {flight_live(fo)}")
    w.fetch("s1")
    _, bo = run(w, "s1", "branch", "--no-fetch")
    REC.check("l3", "branch(s1)", "merged" not in bo.lower() and "checkout -B" not in bo,
              f"live branch told: {bo.strip().splitlines()[:2]}")
    return w


def scen_l_continue():
    """PL-8JQQ: squash merge, then the branch keeps committing on the same item without a new claim."""
    w = World("l4", 3)
    br = "claude/alpha-l4l4l4"
    w.start("s1", br); w.tick(); w.claim("s1", X); w.work("s1", X)
    w.push("s1"); w.open_pr("s1", f"{X}: first half"); w.tick(); w.squash_merge(br); w.tick()
    w.work("s1", X, "sim-work/second-half.txt"); w.push("s1"); w.tick()
    w.fetch("s2")
    offered, excluded, _ = w.next_ids("s2")
    _, so = run(w, "s1", "show", X)
    _, bo = run(w, "s1", "branch")
    REC.note("l4", "next/show", f"s2 next offers {X}={X in offered}; s1's own show: "
             f"{[l.strip() for l in so.splitlines() if 'FLIGHT' in l or 'claim' in l.lower()][:2]}; s1 branch: {bo.strip().splitlines()[0][:90]}")
    _, st = run(w, "s2", "stranded", "--no-fetch")
    REC.check("l4", "stranded(orphaned)", not orphan_clean(st), "post-merge work not reported")
    return w


def scen_harness_upstream():
    """The web harness's own branch shape: upstream = origin/main (as in this very session)."""
    w = World("u", 2)
    w.git("s1", "checkout", "-q", "-b", "claude/web-uuuu01", "--track", "origin/main")
    w.s["s1"].branch = "claude/web-uuuu01"
    c, o = w.claim("s1", X); dump(w, "claim on harness-shaped branch", o)
    REC.check("u", "claim(upstream origin/main)", c == 0, f"exit {c}: {o.strip()[:160]}", "noisy-correct")
    return w


SCENARIOS = {
    "a1": scen_a1, "a2": scen_a2, "a3": scen_a3, "b": scen_b,
    "c": lambda: scen_c(True, False, "c"), "c_open": lambda: scen_c(False, False, "c_open"),
    "d": lambda: scen_c(True, True, "d"), "e": scen_e, "f": scen_f, "g": scen_g, "h": scen_h,
    "i": scen_i, "i2": scen_i2, "j": scen_j, "k": scen_k, "l1": scen_l_postmerge, "l2": scen_l_settled,
    "u": scen_harness_upstream, "l3": scen_l_record, "l4": scen_l_continue,
}


def main_scenarios(names):
    if DUMP.exists():
        for name in names:
            (DUMP / f"{name}.txt").unlink(missing_ok=True)
    for name in names:
        print(f"== {name}: {SCENARIOS[name].__doc__ or ''}".strip()[:120])
        try:
            w = SCENARIOS[name]()
            (DUMP / f"{name}.log").write_text("\n".join(w.log_lines))
        except Exception as error:  # a crash in the tool or the harness
            REC.findings.append(Finding(name, "harness", "CRASH", str(error)[:400], "crash"))
            print(f"  [CRASH] {name}: {str(error)[:400]}")
    out = SIM / "runs" / "results.json"
    old = json.loads(out.read_text()) if out.exists() else []
    old = [f for f in old if f["scenario"] not in names and not any(f["scenario"].startswith(n) for n in names)]
    out.write_text(json.dumps(old + [f.__dict__ for f in REC.findings], indent=1))


# --------------------------------------------------------------------------- randomized
POOL = [X, Y, Z, "PL-B396"]


class RandomRun:
    """Seeded random interleavings over s1..s3 with an always-fetched oracle clone."""

    def __init__(self, seed: int, steps: int) -> None:
        self.rng = random.Random(seed)
        self.seed = seed
        self.steps = steps
        self.w = World(f"rand{seed}", 3)
        self.w.add_session("oracle")
        self.w.git("oracle", "checkout", "-q", "--detach", "origin/main")
        self.trace: list[str] = []
        self.believers: dict[tuple[str, str], str] = {}  # (session, item) -> branch told exit 0
        self.merged_at: dict[str, int] = {}  # branch -> commit count at merge
        self.violations: list[tuple[int, str, str]] = []
        self.n = 0

    # ---- ops
    def op(self) -> str:
        w, r = self.w, self.rng
        who = r.choice(["s1", "s2", "s3"])
        ses = w.s[who]
        pr = w.prs.get(ses.branch)
        if not ses.branch or (pr and pr.state != "open" and r.random() < 0.7):
            w.fetch(who)
            self.n += 1
            w.start(who, f"claude/r{self.seed}-{who}-{self.n:02d}")
            ses.pushed = False
            return f"{who} fetch+start"
        choice = r.choices(
            ["capture", "claim", "claim_nf", "work", "close", "push", "open_pr", "merge_main",
             "squash", "close_pr", "delete", "fetch", "tick", "days", "yield"],
            weights=[6, 10, 4, 8, 4, 10, 6, 3, 7, 2, 3, 8, 8, 1, 2])[0]
        if choice == "capture":
            ids = w.capture(who, f"random capture {self.n} by {who}")
            self.n += 1
            return f"{who} capture {ids}"
        if choice in ("claim", "claim_nf"):
            item = r.choice(POOL)
            code, out = w.claim(who, item, no_fetch=choice == "claim_nf")
            dump(w, f"{who} claim {item}", out)
            if code == 0 and "nothing written" not in out:
                self.believers[(who, item)] = ses.branch
            return f"{who} {choice} {item} -> {code}"
        if choice == "work":
            mine = [i for (s_, i), b in self.believers.items() if s_ == who and b == ses.branch]
            item = r.choice(mine or POOL)
            w.work(who, item)
            return f"{who} work {item}"
        if choice == "close":
            mine = [i for (s_, i), b in self.believers.items() if s_ == who and b == ses.branch]
            if not mine:
                return f"{who} close (nothing claimed)"
            item = r.choice(mine)
            text = w.item_path(who, item).read_text()
            if "status: done" in text:
                return f"{who} close {item} (already)"
            w.set_status(who, item, "done")
            self.believers.pop((who, item), None)  # closing in the branch's copy releases the claim
            return f"{who} close {item}"
        if choice == "push":
            try:
                w.push(who)
            except RuntimeError as error:
                return f"{who} push refused ({str(error).splitlines()[-1][:60]})"
            return f"{who} push"
        if choice == "open_pr":
            if ses.pushed and (pr is None or pr.state != "open"):
                w.open_pr(who)
                return f"{who} open_pr #{w.prs[ses.branch].number}"
            return f"{who} open_pr (n/a)"
        if choice == "merge_main":
            try:
                w.merge_main_in(who)
            except RuntimeError:
                w.git(who, "merge", "--abort", check=False)
                return f"{who} merge_main (conflict, aborted)"
            return f"{who} merge_main"
        if choice == "squash":
            open_ = [b for b, p in w.prs.items() if p.state == "open"]
            if not open_:
                return "squash (none open)"
            b = r.choice(open_)
            # GitHub squashes the remote head: refresh what the PR will merge.
            try:
                w.squash_merge(b)
            except RuntimeError:
                w.git("gh", "reset", "-q", "--hard", "origin/main", check=False)
                return f"squash {b} (conflict)"
            self.merged_at[b] = int(w.git("gh", "rev-list", "--count", f"origin/{b}").stdout.strip())
            return f"squash {b}"
        if choice == "close_pr":
            open_ = [b for b, p in w.prs.items() if p.state == "open"]
            if not open_:
                return "close_pr (none)"
            b = r.choice(open_)
            w.close_pr(b)
            return f"close_pr {b}"
        if choice == "delete":
            done = [b for b, p in w.prs.items() if p.state != "open"]
            live = set(w.git("gh", "ls-remote", "--heads", "origin").stdout.split())
            done = [b for b in done if f"refs/heads/{b}" in live]
            if not done:
                return "delete (none)"
            b = r.choice(done)
            w.delete_branch(b)
            return f"delete {b}"
        if choice == "fetch":
            w.fetch(who)
            return f"{who} fetch"
        if choice == "tick":
            w.tick(r.choice([1, 5, 30, 120]))
            return "tick"
        if choice == "days":
            w.t += timedelta(days=r.choice([3, 8]))
            return "tick days"
        if choice == "yield":
            mine = [i for (s_, i), b in self.believers.items() if s_ == who and b == ses.branch]
            if not mine:
                return f"{who} yield (none)"
            item = r.choice(mine)
            code, out = w.docket(who, "yield", item)
            dump(w, f"{who} yield {item}", out)
            if code == 0:
                self.believers.pop((who, item), None)
            return f"{who} yield {item} -> {code}"
        return "noop"

    # ---- invariants, read from the oracle (fetched every step) and the actor
    def violate(self, step: int, inv: str, detail: str) -> None:
        self.violations.append((step, inv, detail))
        print(f"    !! step {step} {inv}: {detail}")

    def check(self, step: int, actor: str) -> None:
        w = self.w
        w.fetch("oracle")
        w.git("oracle", "checkout", "-q", "--detach", "origin/main")
        _, fo = w.docket("oracle", "flight")
        live = flight_live(fo)
        offered, excluded, _ = w.next_ids("oracle")
        remote = set(w.git("gh", "ls-remote", "--heads", "origin").stdout.split())
        for item in POOL:
            on_main = w.git("oracle", "grep", "-l", "^status: done", "HEAD", "--", f"docs/items/{item}-*", check=False).stdout
            holders = live.get(item, [])
            if len(holders) > 1:
                self.violate(step, "I-single-holder", f"flight lists {item} live on {holders}")
            _, so = w.docket("oracle", "show", item)
            holder = show_holder(so)
            if holders and not on_main:
                if item in offered:
                    self.violate(step, "I-next-held", f"next offers {item} held by {holders}")
                if not holder or not any(h.endswith(holder.split("/")[-1]) for h in holders):
                    self.violate(step, "I-agree", f"flight says {holders}, show says '{holder}'")
            if holder and not holders and "IN FLIGHT" in so:
                self.violate(step, "I-agree", f"show says {holder}, flight has no live row for {item}")
            # believers: sessions told exit 0 whose claim is live and pushed
            for (who, it), branch in list(self.believers.items()):
                if it != item or on_main:
                    continue
                pr = w.prs.get(branch)
                visible = f"refs/heads/{branch}" in remote
                if pr and pr.state != "open":
                    continue
                if not visible:
                    continue
                if w.s[who].branch != branch:
                    continue
                own = [h for h in holders if h.endswith(branch)]
                if not holder and item in offered:
                    lapsed = any(r_[0] == item and r_[1].endswith(branch) and r_[2] == "lapsed"
                                 for r_ in flight_rows(fo))
                    if not lapsed:
                        self.violate(step, "I-believer-unseen", f"{who} was told it holds {item} on {branch} "
                                     f"(exit 0); a fetched clone sees no holder and next offers it")
                if holder and not holder.endswith(branch) and not own:
                    lapsed = any(r_[0] == item and r_[1].endswith(branch) and r_[2] == "lapsed"
                                 for r_ in flight_rows(fo))
                    if not lapsed:
                        self.violate(step, "I-believer", f"{who} was told it holds {item} on {branch}; "
                                     f"oracle show names {holder}")
        for branch, pr in w.prs.items():
            if pr.state == "merged":
                count_now = w.git("oracle", "rev-list", "--count", f"origin/{branch}", check=False).stdout.strip()
                if count_now and count_now.isdigit() and int(count_now) == self.merged_at.get(branch, -1):
                    for item, refs in live.items():
                        if any(r_.endswith(branch) for r_ in refs):
                            self.violate(step, "I-merged-held", f"{item} live on merged {branch}")
        # arm for the actor
        ses = w.s[actor]
        if ses.branch:
            _, ao = w.docket(actor, "arm", "--no-fetch")
            behind = int(w.git(actor, "rev-list", "--count", "HEAD..origin/main").stdout.strip())
            m = re.match(r"behind (\d+)", ao)
            if m and int(m.group(1)) != behind:
                self.violate(step, "I-arm-behind", f"arm says behind {m.group(1)}, rev-list says {behind}")
            if ao.startswith("arm") and behind:
                self.violate(step, "I-arm-behind", f"arm while {behind} behind")
            pr = w.prs.get(ses.branch)
            if pr and pr.state == "merged" and ao.startswith(("arm", "behind")):
                self.violate(step, "I-arm-merged", f"arm on merged #{pr.number}: {ao.splitlines()[0][:70]}")
            # next in the actor's clone offering what origin/main has closed
            offered_a, _, _ = w.next_ids(actor)
            for item in POOL:
                done = w.git(actor, "grep", "-l", "^status: done", "origin/main", "--", f"docs/items/{item}-*", check=False).stdout
                if done and item in offered_a:
                    self.violate(step, "I-next-closed", f"{actor} next offers {item}, done on its origin/main")

    def go(self) -> None:
        for step in range(1, self.steps + 1):
            before = self.w.t
            text = self.op()
            actor = next((p for p in text.split() if re.fullmatch(r"s[123]", p)), "s1")
            self.trace.append(f"{step:02d} [{before:%m-%d %H:%M}] {text}")
            print(f"  {self.trace[-1]}")
            try:
                self.check(step, actor)
            except RuntimeError as error:
                self.violate(step, "harness", str(error)[:200])
        (DUMP / f"rand{self.seed}.trace").write_text("\n".join(self.trace) + "\n\n" + "\n".join(
            f"step {s_}: {i}: {d}" for s_, i, d in self.violations))
        (DUMP / f"rand{self.seed}.log").write_text("\n".join(self.w.log_lines))


def main_random(k: int, steps: int, seed: int) -> None:
    DUMP.mkdir(parents=True, exist_ok=True)
    summary = {}
    for i in range(k):
        run_ = RandomRun(seed + i, steps)
        print(f"== random seed {seed + i}")
        run_.go()
        summary[seed + i] = run_.violations
    (SIM / "runs" / f"random-{seed}.json").write_text(json.dumps(summary, indent=1))
    kinds: dict[str, int] = {}
    for vs in summary.values():
        for _, inv, _ in vs:
            kinds[inv] = kinds.get(inv, 0) + 1
    print("violations by invariant:", kinds)


if __name__ == "__main__":
    if sys.argv[1] == "forge":
        # Stand-in for tools/open_pull_requests.py: `<branch> <number>` per OPEN pull request,
        # exit 1 (could not ask) when the forge is down - the contract docket.toml's command owes.
        state_path = os.environ.get("SIM_PR_STATE", "")
        if os.environ.get("SIM_FORGE_DOWN") or not state_path or not os.path.exists(state_path):
            sys.exit(1)
        for branch_, pr_ in sorted(json.loads(Path(state_path).read_text()).items()):
            if pr_["state"] == "open":
                print(f"{branch_} {pr_['number']}")
    elif sys.argv[1] == "template":
        build_template()
    elif sys.argv[1] == "scenarios":
        main_scenarios(sys.argv[2:] or list(SCENARIOS))
    elif sys.argv[1] == "random":
        main_random(int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]))
