"""Manual primary-mechanism labels for the Q2 population (apparatus-lane defects filed 09-15..09-25).

Classes (A-H as given, plus three added because the data demanded them):
  A  heuristic recognition of text: regex/substring guesses at what prose, code, a
     commit subject, a shell command or front matter means (doc_check citations,
     verify's assert/suppression greps, FIELD_RE, duplicate/recurrence matching)
  B  distributed-state inference: holder/in-flight/stranded/landed/which-PR/which-commit
     decided from git refs, subjects and ages where the truth is on GitHub or another clone
     (includes merge-skew on main and the MB2W claim build items, tagged 'build')
  C  two definitions of one question (two modules, two copies, base vs branch copy)
  D  a recorded statement (doc, rule, skill, item field, ROADMAP entry) restates a fact and drifts
  E  git plumbing edge: exit codes, failed calls read as answers, renames, splitlines, path prefixes
  F  instruction/process ambiguity or a rule/contract with no passing route
  G  output/UX: correct-ish answer, misleading/unscannable/incomplete message
  V  NEW: verify:-command-as-proof - a per-item shell string standing in for 'is the work done'
     flips, can never pass, or proves nothing (PL-6TP8 / PL-1P5V family)
  P  NEW: plan/gate/wave/release semantics - docket's model of milestones, gates, blocked
     states and generator ranking misses a case
  H  other: env = local-vs-CI/container divergence; crash = unguarded exception; perf;
     cover = detector/measurement scope gap; bug = plain logic/arith/flag bug
Confidence: 'a' marks a label where a second class was nearly as good.
"""
L = {
# id: (class, sub/ambiguity note)
"PL-6QZP": ("D", ""), "PL-7CSP": ("P", ""), "PL-7VSK": ("V", ""), "PL-85NT": ("B", "a:F"),
"PL-99YZ": ("B", ""), "PL-B5VM": ("V", ""), "PL-MXSL": ("H", "env"), "PL-PFK1": ("G", ""),
"PL-Q8RQ": ("V", ""), "PL-QSJM": ("H", "env"), "PL-SYG4": ("P", ""), "PL-VZYS": ("H", "env"),
"PL-Y1W6": ("V", ""), "PL-Z9K5": ("C", ""), "PL-2M4X": ("D", "a:V"), "PL-32Z9": ("V", ""),
"PL-4RHP": ("D", ""), "PL-5D2R": ("F", ""), "PL-6YL1": ("V", "a:D"), "PL-7K8Y": ("C", ""),
"PL-C6XD": ("C", ""), "PL-D584": ("D", ""), "PL-DMDF": ("H", "perf"), "PL-JTHW": ("B", "a:G"),
"PL-KND7": ("V", ""), "PL-L4KX": ("C", ""), "PL-L8RN": ("H", "cover"), "PL-LKFP": ("B", ""),
"PL-M21Q": ("F", ""), "PL-N638": ("F", ""), "PL-R0Q0": ("C", "a:P"), "PL-RCQM": ("V", ""),
"PL-SH9Q": ("B", ""), "PL-SY1J": ("B", ""), "PL-WXX8": ("B", "a:F"), "PL-XF2Y": ("V", ""),
"PL-Y1L0": ("P", ""), "PL-Y88W": ("D", ""), "PL-ZF2G": ("P", ""), "PL-3BYK": ("G", ""),
"PL-3DC7": ("C", ""), "PL-4Q9B": ("B", ""), "PL-6T44": ("C", ""), "PL-6TN8": ("V", ""),
"PL-6TP8": ("V", ""), "PL-7TYC": ("A", ""), "PL-FXBS": ("V", ""), "PL-H8YD": ("C", "a:B"),
"PL-HWW1": ("A", ""), "PL-K1WS": ("A", ""), "PL-K82G": ("A", "a:F"), "PL-KSCW": ("B", ""),
"PL-L40Z": ("A", ""), "PL-LBW5": ("D", "a:V"), "PL-Q9Z1": ("E", ""), "PL-QJQL": ("A", ""),
"PL-SWP3": ("B", ""), "PL-09G9": ("V", ""), "PL-0SVP": ("C", "a:G"), "PL-13PB": ("F", ""),
"PL-245B": ("D", ""), "PL-2BZY": ("B", ""), "PL-2DTK": ("B", "a:A"), "PL-2T03": ("C", "a:P"),
"PL-3CTW": ("B", ""), "PL-4FD2": ("A", ""), "PL-4MVC": ("G", ""), "PL-5MFL": ("A", ""),
"PL-5QLP": ("C", ""), "PL-61MD": ("B", ""), "PL-73P0": ("E", ""), "PL-9FNV": ("F", ""),
"PL-BHBZ": ("A", ""), "PL-BSYZ": ("D", ""), "PL-BX1C": ("C", ""),
"PL-C97K": ("G", ""), "PL-CNJH": ("A", ""), "PL-CWD4": ("V", ""), "PL-D1NT": ("H", "crash"),
"PL-DK8Y": ("G", ""), "PL-DN5K": ("B", ""), "PL-GJPD": ("B", ""), "PL-HJZW": ("G", "a:C"),
"PL-LN3T": ("P", ""), "PL-LSR0": ("H", "cover"), "PL-MFM4": ("B", ""), "PL-MM7F": ("E", ""),
"PL-MN0F": ("G", ""), "PL-NWSK": ("C", "a:B"), "PL-QMC0": ("C", ""), "PL-QSGX": ("B", ""),
"PL-R77L": ("C", ""), "PL-RY2R": ("B", ""), "PL-STC4": ("A", ""), "PL-SZJ2": ("P", ""),
"PL-V8QG": ("F", "a:D"), "PL-VHVJ": ("A", ""), "PL-VJPJ": ("H", "crash"), "PL-VKGJ": ("C", ""),
"PL-VYSP": ("B", ""), "PL-WG7Q": ("B", ""), "PL-WVJ0": ("D", ""), "PL-X3NY": ("B", ""),
"PL-XQGH": ("A", ""), "PL-Y5JX": ("D", "a:C"), "PL-YFXG": ("B", ""), "PL-YS9F": ("P", ""),
"PL-Z27P": ("G", ""), "PL-Z6M3": ("G", "a:C"), "PL-ZMGR": ("C", "a:F base-copy contract"),
"PL-ZPDM": ("E", ""), "PL-087W": ("A", "a:B"), "PL-162Y": ("C", ""), "PL-1X2C": ("B", ""),
"PL-205P": ("V", ""),
"PL-34BG": ("A", ""), "PL-4W2L": ("A", ""), "PL-5B39": ("A", "a:parser"), "PL-5B88": ("A", ""),
"PL-73G8": ("D", "a:B"), "PL-7NKD": ("G", ""), "PL-8JQQ": ("B", ""), "PL-BYMX": ("B", ""),
"PL-DGP0": ("A", "a:G"), "PL-FCM3": ("G", ""), "PL-G21K": ("A", ""), "PL-H6VQ": ("A", ""),
"PL-J3WK": ("C", "a:V"), "PL-K4R5": ("C", "a:F base-copy contract"), "PL-N2PP": ("B", ""),
"PL-NGBM": ("E", "a:C"), "PL-P4XB": ("H", "crash"), "PL-PQC7": ("F", ""), "PL-RR1N": ("V", "a:A"),
"PL-S8JT": ("D", ""), "PL-T441": ("E", "a:C"), "PL-W7WL": ("B", "a:P"), "PL-WFFX": ("B", ""),
"PL-ZM48": ("D", ""), "PL-3QM9": ("H", "bug"), "PL-44DG": ("H", "cover"), "PL-5DPF": ("H", "cover"),
"PL-6SRZ": ("A", ""), "PL-9HD1": ("A", "a:parser"), "PL-B78T": ("B", ""), "PL-CJ5R": ("F", "a:P"),
"PL-CR36": ("H", "env"), "PL-CZR6": ("B", ""), "PL-D8KW": ("D", ""), "PL-H0CF": ("H", "env"),
"PL-HVLJ": ("B", ""), "PL-J3TV": ("D", ""), "PL-KYW3": ("C", ""), "PL-M7W1": ("B", ""),
"PL-N0MH": ("G", ""),
"PL-NPWP": ("B", ""), "PL-RFHH": ("C", ""), "PL-V6CR": ("A", "a:parser"), "PL-YSMV": ("A", ""),
"PL-YZJD": ("C", "a:F base-copy contract"), "PL-Z891": ("A", ""), "PL-ZM8P": ("C", ""),
"PL-19T3": ("E", ""), "PL-1P5V": ("V", ""), "PL-3W3P": ("B", ""), "PL-8FJK": ("B", ""),
"PL-8GV1": ("B", ""), "PL-8YXJ": ("D", ""), "PL-9RFP": ("E", ""), "PL-B60Q": ("F", "a:D"),
"PL-BBT8": ("C", ""), "PL-DNZ0": ("A", ""), "PL-DSPM": ("A", "a:parser"), "PL-J16N": ("E", "a:B"),
"PL-R812": ("V", ""), "PL-RMN8": ("H", "bug"), "PL-WF3X": ("E", "a:C"), "PL-WNCT": ("B", ""),
"PL-X229": ("E", ""), "PL-YKSD": ("B", ""), "PL-1MCK": ("B", ""), "PL-1PBV": ("E", ""),
"PL-1SFZ": ("A", ""), "PL-27VL": ("G", ""), "PL-59QW": ("D", ""), "PL-5MYR": ("H", "cover"),
"PL-70VB": ("B", "merge-skew"), "PL-9VPH": ("F", ""), "PL-B8HZ": ("C", ""), "PL-F5NV": ("H", "bug"),
"PL-FD5Q": ("P", ""), "PL-GVFC": ("A", ""), "PL-HMZZ": ("B", ""), "PL-JD4L": ("A", "a:parser"),
"PL-JLYG": ("P", "a:B"),
"PL-KH3Q": ("B", "merge-skew"), "PL-KSV2": ("C", ""), "PL-KWCY": ("B", ""), "PL-MB2W": ("B", ""),
"PL-PK4B": ("H", "crash"), "PL-PXZ3": ("B", ""), "PL-PZ6T": ("C", ""), "PL-QHCW": ("B", ""),
"PL-QP9Z": ("B", ""), "PL-SLCC": ("B", "a:E"), "PL-WM46": ("A", ""), "PL-ZJ6X": ("C", ""),
"PL-0TD9": ("B", "build"), "PL-139L": ("E", ""), "PL-2P5L": ("H", "env"), "PL-331V": ("B", "build"),
"PL-3FYK": ("B", "build"), "PL-4RK2": ("P", ""), "PL-9F8B": ("C", "a:G"), "PL-CH3Z": ("B", "build"),
"PL-DDYD": ("B", "build"), "PL-FX5Q": ("B", "build"), "PL-H14W": ("B", ""), "PL-N162": ("B", "build"),
"PL-NST2": ("B", "build"), "PL-PRSF": ("G", "a:B"), "PL-QFWF": ("P", ""), "PL-SL16": ("F", ""),
"PL-SL4L": ("G", ""), "PL-TP75": ("C", ""), "PL-WX87": ("B", ""),
}
# Discovery overrides after reading the body (auto rule otherwise; see classify.py)
DISC = {
"PL-MN0F": "iv", "PL-7VSK": "iii", "PL-B5VM": "iii", "PL-Y1W6": "iii", "PL-32Z9": "iii",
"PL-KND7": "iii", "PL-XF2Y": "iii", "PL-85NT": "iii", "PL-QSJM": "iii", "PL-70VB": "iii",
"PL-KH3Q": "iii", "PL-D1NT": "iii", "PL-H8YD": "iii",
"PL-WFFX": "ii",  # owner supplied a fact ("merged from phone") to PL-843V's investigation; not owner-reported
}
