#!/usr/bin/env bash
# Reproduce every number: run from /home/user/open-anesthesia-sim (read-only; writes only into /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow)
set -euo pipefail
cd /home/user/open-anesthesia-sim
python3 /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow/inflow.py > /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow/report.txt          # Q1 inflow/closure/backlog, Q3 self-generation, Q5 hot files
python3 /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow/q2view.py > /dev/null              # Q2 population listing (q2_compact.txt)
python3 /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow/classify.py > /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow/q2_classes.txt    # Q2 class and discovery tables (+ q2_labelled.tsv)
bin/docket generators > /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow/generators.txt
python3 /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow/generators_map.py > /tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/inflow/q4_generators.txt
