"""Compact listing of the Q2 population for manual classification."""
import sys, re, datetime as dt
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, "subprojects/docket/src"); sys.path.insert(0, str(HERE))
from docket.store import read_items
import inflow
items = read_items(Path("docs/items"))
L = {i.identifier: inflow.lane(i) for i in items}
rows = inflow.commit_walk()
cap = {}
for r in rows:
    for n in r["new"]:
        cap.setdefault(n, r)
q2 = sorted((i for i in items if i.added and inflow.W0 <= i.added <= inflow.D1
             and L[i.identifier] == "apparatus" and "defect" in i.classes),
            key=lambda i: (i.added, i.identifier))
out = []
for i in q2:
    r = cap.get(i.identifier)
    lead = [f"{x}{'' if L.get(x)=='apparatus' else '/'+L.get(x,'?')[:3]}" for x in (r["lead"] if r else [])]
    body = re.sub(r"\s+", " ", i.body)
    body = re.sub(r"^\*\*Problem\.\*\*\s*", "", body)
    if body.startswith(i.title[:40]):
        body = body[len(i.title):].strip()
    flags = [k for k, rx in inflow.DISCOVERY_FLAGS.items() if re.search(rx, i.body, re.I)]
    out.append(f"{i.identifier} {str(i.added)[5:]} {i.status[:4]} | {i.title[:240]}\n   cap={r['sha'][:7] if r else '-'} lead={','.join(lead)} flags={','.join(flags)}\n   > {body[:280]}")
(HERE / "q2_compact.txt").write_text("\n".join(out) + "\n")
print(len(out))
