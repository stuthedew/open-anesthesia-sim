"""Tabulate Q2 (mechanism class x discovery path) from labels.py; run from repo root."""
import sys, re, collections
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, "subprojects/docket/src"); sys.path.insert(0, str(HERE))
from docket.store import read_items
import inflow, labels

items = read_items(Path("docs/items"))
by_id = {i.identifier: i for i in items}
Ln = {i.identifier: inflow.lane(i) for i in items}
rows = inflow.commit_walk()
cap = {}
for r in rows:
    for n in r["new"]:
        cap.setdefault(n, r)
q2 = sorted((i for i in items if i.added and inflow.W0 <= i.added <= inflow.D1
             and Ln[i.identifier] == "apparatus" and "defect" in i.classes),
            key=lambda i: (i.added, i.identifier))
ids = [i.identifier for i in q2]
missing = [x for x in ids if x not in labels.L]
extra = [x for x in labels.L if x not in ids]
print("unlabelled:", missing, "extra:", extra)

OWNER = re.compile(r"project owner (reported|noticed|flagged|raised|caught|spotted|asked why|found)|reported (it )?by the project owner|The project owner reported|owner's report", re.I)
CI = re.compile(r"^\s*(\*\*Problem\.\*\*\s*)?`?main`? (is|was|has been) red|Found[^.]{0,40}by CI|CI fail", re.I)
FOUND_IN = re.compile(r"(Found|Observed|Measured|Hit|Surfaced|Split out of|Reproduced)[^.\n]{0,80}?`?(PL-[0-9A-Z]{3,4})`?")

def discovery(i):
    x = i.identifier
    if x in labels.DISC:
        return labels.DISC[x], "manual"
    body = i.title + "\n" + i.body
    if OWNER.search(body):
        return "iv", "owner phrase"
    if CI.search(i.body[:300]) or CI.search(i.title):
        return "iii", "main red / CI"
    r = cap.get(x)
    others = [y for y in (r["lead"] if r else []) if y != x]
    lanes = {Ln.get(y, "?") for y in others}
    if lanes - {"simulator"}:
        return "ii", "captured in another apparatus-side item's commit"
    m = FOUND_IN.search(i.body[:1500])
    if m and m.group(2) != x:
        l2 = Ln.get(m.group(2), "?")
        if l2 == "simulator":
            return "i", f"found in {m.group(2)} (sim)"
        return "ii", f"found in {m.group(2)} ({l2})"
    if lanes == {"simulator"}:
        return "i", "captured in a simulator item's commit"
    return "v", "self-led or no lead, no 'found in' id"

tab = collections.Counter(); disc = collections.Counter(); cd = collections.Counter()
amb = 0; sub = collections.Counter()
out = []
for i in q2:
    c, note = labels.L[i.identifier]
    d, why = discovery(i)
    tab[c] += 1; disc[d] += 1; cd[(c, d)] += 1
    if note.startswith("a:"):
        amb += 1
    if c == "H" or note in ("build", "merge-skew"):
        sub[f"{c}:{note.split()[0] if note else ''}"] += 1
    out.append(f"{i.identifier}\t{i.added}\t{i.status}\t{c}\t{note}\t{d}\t{why}\t{i.title[:120]}")
(HERE / "q2_labelled.tsv").write_text("id\tadded\tstatus\tclass\tnote\tdisc\twhy\ttitle\n" + "\n".join(out) + "\n")
n = len(q2)
print(f"n={n}; ambiguous (second class nearly as good) = {amb}")
names = {"A":"heuristic text recognition","B":"distributed-state inference","C":"two definitions","D":"recorded statement drifts","E":"git plumbing edge","F":"instruction/process","G":"output/UX","V":"verify-command-as-proof","P":"plan/gate/release semantics","H":"other"}
print("class counts:")
for k, v in tab.most_common():
    print(f"  {k} {names[k]:32} {v:4} {100*v/n:5.1f}%")
print("H/B subtypes:", dict(sub))
print("discovery:", {k: f"{v} ({100*v/n:.0f}%)" for k, v in sorted(disc.items())})
print("class x discovery:")
ks = sorted(disc)
print("      " + " ".join(f"{k:>4}" for k in ks))
for c, _ in tab.most_common():
    print(f"  {c:3} " + " ".join(f"{cd[(c,k)]:4}" for k in ks))
# per-day by class
print("per day by class:")
days = sorted({str(i.added) for i in q2})
cls = [c for c, _ in tab.most_common()]
print("  date  " + " ".join(f"{c:>3}" for c in cls) + "  tot")
for d in days:
    cc = collections.Counter(labels.L[i.identifier][0] for i in q2 if str(i.added) == d)
    print(f"  {d[5:]} " + " ".join(f"{cc[c]:3}" for c in cls) + f"  {sum(cc.values()):3}")

OPEN = ("ready", "blocked", "needs-decision", "untriaged")
print("still open by class:", {c: sum(1 for i in q2 if labels.L[i.identifier][0] == c and i.status in OPEN) for c in cls},
      "total open", sum(1 for i in q2 if i.status in OPEN))
GATE = re.compile(r"REJECT|refuses? (a |the )?correct|fails make check|make check (red|fails)|turns? make check red|false positive", re.I)
g = [i.identifier for i in q2 if GATE.search(i.title + " " + i.body[:1200])]
print(f"indicator - an apparatus gate refusing correct work (REJECT / refuses correct / make check red / false positive) in title or first 1200 chars: {len(g)} of {n}")
