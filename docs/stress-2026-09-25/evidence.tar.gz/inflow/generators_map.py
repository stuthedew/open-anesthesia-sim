"""Q4: map the recorded generator heads onto mechanism classes (by misread line + head)."""
import sys, collections
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, "subprojects/docket/src"); sys.path.insert(0, str(HERE))
from docket.store import read_items
from docket.plan import clusters
import inflow
HEAD = {  # head: class   (misread fact abbreviated)
"PL-4FBP": "D", "PL-G424": "D",                      # doc sentence <-> tree fact it restates
"PL-4Q9B": "B", "PL-R808": "B", "PL-BHVM": "B", "PL-GHHW": "B",  # remote refs; base holds change
"PL-HMZZ": "B", "PL-XYQW": "B",                      # which PR carried the work
"PL-QHCW": "B",                                      # which commit a release was cut on
"PL-7TVT": "B", "PL-MB2W": "B", "PL-8FJK": "B",      # who holds an item
"PL-WFFX": "B",                                      # squash subject/body as merge sends them
"PL-WNCT": "B",                                      # pushed work has an open PR to carry it
"PL-6TP8": "V", "PL-1P5V": "V",                      # what verify: exit status proves
"PL-B8HZ": "C",                                      # base's or branch's copy authoritative
"PL-ZJ6X": "C",                                      # which strings are valid ids
"PL-L4YG": "C",                                      # canonical serialized item form
"PL-0HPV": "C",                                      # local gate vs merge gate check sets
"PL-6T44": "C",                                      # queue state (next/wave vs check)
"PL-8YXJ": "D",                                      # queue state (brief prose narrates old state)
"PL-NGBM": "E", "PL-9RFP": "E",                      # store path prefix; git answered or failed
"PL-G21K": "A", "PL-4W2L": "A",                      # diff weakens tests (text matcher)
"PL-TZ7T": "A",                                      # open item already describes capture (text similarity)
"PL-9HD1": "A",                                      # front-matter value grammar (FIELD_RE)
"PL-HWW1": "A",                                      # Required-scope members vs cited ids (prose)
"PL-J6HP": "P", "PL-WD5Z": "P",                      # debt item's gate disposition
"PL-2T03": "P",                                      # release train arrangement
"PL-LN69": "F",                                      # whether a resident instruction changes behaviour
"PL-YRYR": "H",                                      # test-commit cost set by machine git config (env)
"PL-KRZW": "sim",                                    # palette roles (simulator UI, not apparatus)
}
items = read_items(Path("docs/items"))
g = clusters(items)
print(len(g), "heads;", "unmapped:", [h for h in g if h not in HEAD], "stale:", [h for h in HEAD if h not in g])
heads = collections.Counter(); members = collections.Counter(); distinct = collections.defaultdict(set)
open_m = collections.Counter()
for h, c in g.items():
    k = HEAD[h]
    heads[k] += 1; members[k] += len(c.members)
    distinct[k].update(m.identifier for m in c.members)
    open_m[k] += sum(1 for m in c.members if m.status not in ("done", "dropped"))
allm = set().union(*distinct.values())
print("class heads members(sum) distinct open-members")
for k, v in members.most_common():
    print(f"  {k:4} {heads[k]:3} {v:5} {len(distinct[k]):5} {open_m[k]:5}")
print("total members(sum)", sum(members.values()), "distinct", len(allm))
