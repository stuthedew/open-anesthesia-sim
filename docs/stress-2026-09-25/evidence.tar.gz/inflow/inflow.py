"""Read-only forensic counts over docs/items and origin/main history.

Run from the repository root:
    python3 <scratchpad>/inflow/inflow.py [--dump]

Writes nothing into the repository. Outputs go to the directory this file is in.

LANE RULE (from `touches:` only):
  apparatus paths: subprojects/docket/, tools/, .claude/, .github/, bin/, CLAUDE.md,
    AGENTS.md, docs/worker.md, docs/items/ (weak, see below), docs/maintainer.md,
    docs/resident-instructions.md, docs/pr-bodies/, docs/workflow.md, Makefile,
    docket.toml, and any tests/ file that tests a tools/ script or .claude/hooks
    hook (TOOL_TESTS below).
  simulator paths: src/, tests/ (other than TOOL_TESTS), conftest.py, docs/MODEL.md,
    README.md, docs/ARCHITECTURE.md, docs/references/, docs/machine-*.md,
    docs/interface-provenance.md, docs/consultant-brief.md, docs/dead-ends.md, spikes/, assets/.
  neutral (count for neither): ROADMAP.md, docs/WORKING_NOTES.md, docs/releases/,
    pyproject.toml, uv.lock, .gitignore, CITATION.cff, LICENSE, CONTRIBUTING.md, etc.
  An item is `apparatus` if it names >=1 strong apparatus path and no simulator path;
  `simulator` if it names >=1 simulator path and no strong apparatus path (docs/items
  alone does not make a simulator item mixed, but an item naming docs/items and no
  simulator path is apparatus); `mixed` if both; `neither` if it names only neutral
  paths (releases, ROADMAP, WORKING_NOTES); `notouch` if it has no touches at all
  (mostly captures dropped as duplicates before triage).
"""

from __future__ import annotations

import collections
import datetime as dt
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / "subprojects/docket/src"))
from docket.store import read_items  # noqa: E402

OUT = Path(__file__).resolve().parent
D0, D1 = dt.date(2026, 9, 6), dt.date(2026, 9, 25)
W0 = dt.date(2026, 9, 15)

TOOL_TESTS = {
    # tests of tools/*.py and .claude/hooks/* (current and deleted)
    "test_agent_identity_check", "test_branch_id_check", "test_context_reading",
    "test_contrast_check", "test_core_vocabulary_check", "test_dead_ends",
    "test_doc_check", "test_fixture_id_check", "test_generator_check",
    "test_glyph_check", "test_ignore_check", "test_import_boundary_check",
    "test_item_read_log", "test_item_reads", "test_left_behind_check",
    "test_main_ci_status", "test_open_pull_requests",
    "test_possessive_section_check", "test_pr_body_check", "test_pr_title_check",
    "test_required_checks_check", "test_rules_paths_check",
    "test_workflow_paths_check", "test_docket_branch_guard",
    "test_docket_digest_hook", "test_floor_interpreter_guard",
    "test_gate_status_guard", "test_no_prune_guard", "test_stop_hook_patch",
    "test_tools_portability", "test_ci_concurrency", "test_docket_gate",
    "test_punch_list_tool", "test_readme_hold_check", "test_record_pr_workflow",
}

APP_PREFIX = ("subprojects/docket", "tools", ".claude", ".github", "bin/",
              "docs/pr-bodies")
APP_EXACT = {"CLAUDE.md", "AGENTS.md", "docs/worker.md", "docs/maintainer.md",
             "docs/resident-instructions.md", "docs/workflow.md", "Makefile",
             "docket.toml", "bin", ".claude/", ".github"}
SIM_PREFIX = ("src/", "docs/references", "docs/machine-", "spikes", "assets")
SIM_EXACT = {"docs/MODEL.md", "README.md", "docs/ARCHITECTURE.md",
             "docs/interface-provenance.md", "docs/consultant-brief.md",
             "docs/dead-ends.md", "conftest.py"}


def path_lane(p: str) -> str:
    p = p.strip().strip("`")
    if p.startswith("docs/items"):
        return "weakapp"
    if p in APP_EXACT or p.startswith(APP_PREFIX):
        return "app"
    if p.startswith("tests"):
        stem = Path(p).stem
        if stem in TOOL_TESTS:
            return "app"
        return "sim"
    if p in SIM_EXACT or p.startswith(SIM_PREFIX):
        return "sim"
    return "neutral"


def lane(item) -> str:
    kinds = {path_lane(t) for t in item.touches}
    if not item.touches:
        return "notouch"
    app, sim = "app" in kinds, "sim" in kinds
    if not sim and "weakapp" in kinds:
        app = True  # docs/items-only (triage, recovery, recorded decisions) is queue work
    if app and sim:
        return "mixed"
    if app:
        return "apparatus"
    if sim:
        return "simulator"
    return "neither"


def git(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True,
                          text=True, check=True).stdout


def days(a: dt.date, b: dt.date):
    d = a
    while d <= b:
        yield d
        d += dt.timedelta(days=1)


ID_RE = re.compile(r"PL-[0-9A-Z]{3,4}")


def leading_ids(subject: str) -> list[str]:
    """Ids before the first colon, e.g. 'PL-A, PL-B: ...'."""
    head = subject.split(":", 1)[0] if ":" in subject else ""
    ids = ID_RE.findall(head)
    return ids if ids and head.strip().startswith("PL-") else []


def commit_walk(since: str = "2026-09-01"):
    """First-parent origin/main commits since `since`: item ids new vs parent."""
    log = git("log", "--first-parent", "--reverse", f"--since={since}",
              "--format=%H%x09%cs%x09%s", "origin/main")
    rows = []
    prev_ids = None
    for line in log.splitlines():
        sha, day, subj = line.split("\t", 2)
        def ids_at(rev: str) -> set[str]:
            names = git("ls-tree", "--name-only", f"{rev}:docs/items")
            return {m.group(0) for n in names.splitlines()
                    if (m := re.match(r"PL-[0-9A-Z]+", n))}
        if prev_ids is None:
            prev_ids = ids_at(f"{sha}^1")
        now = ids_at(sha)
        rows.append({"sha": sha, "day": day, "subject": subj,
                     "lead": leading_ids(subj), "new": sorted(now - prev_ids)})
        prev_ids = now
    return rows


def main() -> None:
    items = read_items(ROOT / "docs/items")
    by_id = {it.identifier: it for it in items}
    L = {it.identifier: lane(it) for it in items}
    out = []
    p = out.append

    lanes = ["apparatus", "simulator", "mixed", "neither", "notouch"]
    # ---------- Q1 inflow / closure / backlog ----------
    p("Q1. Items filed (added:) and closed (closed:) per day, by lane")
    p("date       | filed: app sim mix nei noT | appDefect | closed(done+dropped): app sim oth | openApp openSim openAll")
    daily = {}
    for d in days(D0, D1):
        f = collections.Counter(L[i.identifier] for i in items if i.added == d)
        ad = sum(1 for i in items if i.added == d and L[i.identifier] == "apparatus"
                 and "defect" in i.classes)
        c = collections.Counter(L[i.identifier] for i in items
                                if i.closed == d and i.status in ("done", "dropped"))
        cdone_app = sum(1 for i in items if i.closed == d and i.status == "done"
                        and L[i.identifier] == "apparatus")
        def is_open(i):
            return i.added and i.added <= d and not (i.closed and i.closed <= d)
        oa = sum(1 for i in items if is_open(i) and L[i.identifier] == "apparatus")
        os_ = sum(1 for i in items if is_open(i) and L[i.identifier] == "simulator")
        oall = sum(1 for i in items if is_open(i))
        daily[d] = dict(f=f, ad=ad, c=c, oa=oa, os=os_, oall=oall, cdone_app=cdone_app)
        coth = sum(v for k, v in c.items() if k not in ("apparatus", "simulator"))
        p(f"{d} | {f['apparatus']:4} {f['simulator']:3} {f['mixed']:3} {f['neither']:3} {f['notouch']:3} | {ad:9} | {c['apparatus']:4} {c['simulator']:3} {coth:3} | {oa:7} {os_:7} {oall:7}")
    p("")
    p("7-day rolling sums (window ending on date)")
    p("date       | appFiled appDefect appClosed(done+drop) appDone | simFiled simClosed | net app (filed-closed)")
    ds = list(days(D0, D1))
    for k, d in enumerate(ds):
        if k < 6:
            continue
        win = ds[k - 6:k + 1]
        af = sum(daily[x]["f"]["apparatus"] for x in win)
        adf = sum(daily[x]["ad"] for x in win)
        ac = sum(daily[x]["c"]["apparatus"] for x in win)
        adn = sum(daily[x]["cdone_app"] for x in win)
        sf = sum(daily[x]["f"]["simulator"] for x in win)
        sc = sum(daily[x]["c"]["simulator"] for x in win)
        p(f"{d} | {af:8} {adf:9} {ac:20} {adn:7} | {sf:8} {sc:9} | {af - ac:+d}")
    tot_f = collections.Counter(L[i.identifier] for i in items if i.added and D0 <= i.added <= D1)
    tot_c = collections.Counter(L[i.identifier] for i in items if i.closed and D0 <= i.closed <= D1)
    p(f"window totals filed {dict(tot_f)}; closed {dict(tot_c)}")
    tot_ad = sum(daily[d]["ad"] for d in ds)
    p(f"apparatus defects filed in window: {tot_ad} of {tot_f['apparatus']} apparatus filed")
    p(f"items without added: {sum(1 for i in items if not i.added)}")
    p("")

    # ---------- commit walk ----------
    rows = commit_walk()
    capture = {}  # id -> commit row that first brought it to main
    for r in rows:
        for n in r["new"]:
            capture.setdefault(n, r)

    # ---------- Q2 dump of apparatus defects 09-15..25 ----------
    q2 = sorted((i for i in items if i.added and W0 <= i.added <= D1
                 and L[i.identifier] == "apparatus" and "defect" in i.classes),
                key=lambda i: (i.added, i.identifier))
    p(f"Q2. apparatus-lane defect items filed {W0}..{D1}: {len(q2)}")
    with open(OUT / "q2_dump.txt", "w") as fh:
        for i in q2:
            r = capture.get(i.identifier)
            lead = r["lead"] if r else []
            lead_l = [f"{x}:{L.get(x, '?')}" for x in lead]
            self_lead = i.identifier in lead
            body = re.sub(r"\s+", " ", i.body)[:400]
            flags = [k for k, rx in DISCOVERY_FLAGS.items() if re.search(rx, i.body, re.I)]
            fh.write(f"### {i.identifier} [{i.added}] {i.status} P={i.priority} cls={','.join(i.classes)}\n")
            fh.write(f"T: {i.title}\n")
            fh.write(f"capture: {r['sha'][:8] + ' ' + r['subject'][:110] if r else 'NOT FOUND'}\n")
            fh.write(f"lead: {lead_l} selfLead={self_lead} flags={flags}\n")
            fh.write(f"touches: {', '.join(i.touches)}\n")
            fh.write(f"B: {body}\n\n")

    # ---------- Q3 self-generation ----------
    closed_app = [i for i in items if i.closed and W0 <= i.closed <= D1
                  and i.status == "done" and L[i.identifier] == "apparatus"]
    closed_ids = {i.identifier for i in closed_app}
    commits = [r for r in rows if set(r["lead"]) & closed_ids]
    spawned_all, spawned_app, spawned_sim, spawned_oth = set(), set(), set(), set()
    raw_new = set()
    for r in commits:
        for n in r["new"]:
            raw_new.add(n)
            it = by_id.get(n)
            if n in r["lead"]:
                continue  # filed and fixed in the same pull request: net zero
            spawned_all.add(n)
            ln = L.get(n, "?")
            (spawned_app if ln == "apparatus" else spawned_sim if ln == "simulator" else spawned_oth).add(n)
    covered = {x for r in commits for x in r["lead"]} & closed_ids
    p("")
    p(f"Q3. apparatus items closed done {W0}..{D1}: {len(closed_app)}; closing commits found for {len(covered)} ({len(commits)} commits)")
    p(f"  new item ids in those commits: {len(raw_new)}; excluding ids the commit itself leads with: {len(spawned_all)}")
    p(f"  of which apparatus {len(spawned_app)}, simulator {len(spawned_sim)}, other/mixed/neither {len(spawned_oth)}")
    oth_l = collections.Counter(L.get(n, '?') for n in spawned_oth)
    p(f"  other breakdown: {dict(oth_l)}")
    n_c = max(len(covered), 1)
    p(f"  spawn rate (apparatus spawned / apparatus closed with a found commit): {len(spawned_app)}/{len(covered)} = {len(spawned_app)/n_c:.2f}")
    p(f"  spawn rate (all spawned / closed): {len(spawned_all)}/{len(covered)} = {len(spawned_all)/n_c:.2f}")
    st = collections.Counter(by_id[n].status for n in spawned_app if n in by_id)
    p(f"  status now of apparatus spawned: {dict(st)}")
    dropped_app = sum(1 for i in items if i.closed and W0 <= i.closed <= D1
                      and i.status == "dropped" and L[i.identifier] == "apparatus")
    p(f"  (apparatus items dropped in the same window, not counted: {dropped_app})")
    sp_def = sum(1 for n in spawned_app if "defect" in by_id[n].classes)
    p(f"  of the {len(spawned_app)} apparatus spawned, class defect: {sp_def}")
    # per closed-date half-window, each closed item counted once, spawned deduped
    p("  by the closed item's closed: date (each closed item once; spawned ids deduped):")
    for a, b in ((W0, dt.date(2026, 9, 19)), (dt.date(2026, 9, 20), D1)):
        grp = {i.identifier for i in closed_app if a <= i.closed <= b} & covered
        sp = set()
        for r in commits:
            if set(r["lead"]) & grp:
                sp |= {n for n in r["new"] if n not in r["lead"] and L.get(n) == "apparatus"}
        p(f"    {a}..{b}: closed {len(grp)}, spawned apparatus {len(sp)}, rate {len(sp)/max(len(grp),1):.2f}")
    # Where apparatus inflow is captured from, over all first-parent commits since W0
    p("")
    p(f"  All apparatus items first landing on main {W0}..{D1}, by lane of the commit's leading item(s):")
    by_lead = collections.Counter()
    for r in rows:
        if r["day"] < str(W0):
            continue
        for n in r["new"]:
            if L.get(n) != "apparatus":
                continue
            if n in r["lead"] and len(r["lead"]) == 1:
                by_lead["own commit (filed as its own work)"] += 1
                continue
            ll = {L.get(x, "?") for x in r["lead"] if x != n}
            if not ll:
                by_lead["commit leads with no id"] += 1
            elif "apparatus" in ll:
                by_lead["apparatus item's commit"] += 1
            elif "simulator" in ll:
                by_lead["simulator item's commit"] += 1
            else:
                by_lead["other item's commit: " + "/".join(sorted(ll))] += 1
    for k, v in by_lead.most_common():
        p(f"    {v:4}  {k}")

    # ---------- Q5 hot files ----------
    p("")
    q5 = [i for i in items if i.added and i.added >= W0 and "defect" in i.classes
          and L[i.identifier] in ("apparatus", "mixed")]
    hot = collections.Counter(t for i in q5 for t in i.touches
                              if path_lane(t) == "app" and not t.startswith("tests")
                              and "/tests/" not in t)
    p(f"Q5. apparatus source files in touches of defect items filed since {W0} (apparatus+mixed lane, n={len(q5)}; test files excluded)")
    for f, n in hot.most_common(12):
        fp = ROOT / f
        wc = sum(1 for _ in open(fp)) if fp.is_file() else "-"
        p(f"  {n:3}  {wc!s:>6}  {f}")

    (OUT / "report.txt").write_text("\n".join(out) + "\n")
    print("\n".join(out))


DISCOVERY_FLAGS = {
    "found_while": r"found while|surfaced while|hit while|noticed while|turned up while|while (working|fixing|building|shipping|landing|closing|implementing|writing)",
    "session_filed": r"session that (filed|found|wrote|hit)|from the session",
    "owner": r"project owner (reported|asked|noticed|flagged|raised|caught)|owner (reported|flagged|noticed|caught|raised)",
    "review": r"\breview(er|ed)?\b|copilot|codex",
    "ci": r"\bCI\b|quality\.yml|make check (failed|refused)|red on main",
}

if __name__ == "__main__":
    main()
