import sys, re
R="/home/user/open-anesthesia-sim"
sys.path[:0]=[R+"/subprojects/docket/src", R+"/tools"]
from docket import vcs, store
import generator_check as gc
import pr_body_check as pbc
def gc_leading(s):
    m = gc.LEADING_IDS_RE.match(s.strip())
    return sorted(set(gc.ID_RE.findall(m.group(1)))) if m else []
cases = [
 "PL-B8HZ: fix",
 "PL-B8HZ fix without colon",
 "PL-B8HZ and PL-HMZZ: two",
 "PL-B8HZ & PL-HMZZ: two",
 "pl-b8hz: lowercase",
 "PL-N162, PL-FFR0: show, flight (#1002)",
 "Cut v0.5.10 (PL-NLXK) (#990)",
]
for s in cases:
    print(repr(s))
    print("   vcs.leading_ids      :", vcs.leading_ids(s))
    print("   generator_check lead :", gc_leading(s))
    print("   pr_body_check.item_ids:", pbc.item_ids(s, 0, {}))
    print("   BRANCH_ID_RE(branch) :", bool(vcs.BRANCH_ID_RE.search("claude/"+s.split(':')[0].replace(' ','-').lower())))
# alphabet equality
a=set(store.ID_ALPHABET.lower()); 
b=set("0123456789bcdfghjklmnpqrstvwxyz")
print("alphabet same:", a==b)
