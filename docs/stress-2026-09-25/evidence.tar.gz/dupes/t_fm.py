import sys
from pathlib import Path
R=Path("/home/user/open-anesthesia-sim")
sys.path[:0]=[str(R/"subprojects/docket/src"), str(R/"tools")]
from docket.model import parse_item
import generator_check as gc
diffs={}
n=0
for p in sorted((R/"docs/items").glob("PL-*.md")):
    n+=1
    it=parse_item(p.read_text(encoding="utf-8"), str(p))
    f=gc.read_front_matter(p)
    gt=tuple(t.strip() for t in f.get("touches","").split(",") if t.strip())
    gr=tuple(t.strip() for t in f.get("root-cause-of","").split(",") if t.strip())
    mr=tuple(getattr(it,"root_cause_of",()) or ())
    for name,a,b in (("touches",it.touches,gt),("root-cause-of",mr,gr),("status",it.status,f.get("status",""))):
        if tuple(a)!=tuple(b) if not isinstance(a,str) else a!=b:
            diffs.setdefault(name,[]).append((p.name[:8],a,b))
print(n,"items")
for k,v in diffs.items():
    print(k,len(v)); 
    for x in v[:4]: print("   ",x[0],"model:",str(x[1])[:90],"| gc:",str(x[2])[:90])
