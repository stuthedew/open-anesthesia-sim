import sys, tempfile
from pathlib import Path
R=Path("/home/user/open-anesthesia-sim")
sys.path[:0]=[str(R/"subprojects/docket/src"), str(R/"tools")]
from docket.model import parse_item
import generator_check as gc
texts = {
 "block": "---\nid: PL-ZZZZ\ntitle: t\nstatus: ready\ntouches:\n  - tools/a.py\n  - tools/b.py\n---\nbody\n",
 "quoted": "---\nid: PL-ZZZZ\ntitle: t\nstatus: 'ready'\ntouches: \"tools/a.py\", tools/b.py\n---\nbody\n",
 "crlf": "---\r\nid: PL-ZZZZ\r\ntitle: t\r\nstatus: ready\r\ntouches: tools/a.py\r\n---\r\nbody\r\n",
}
for k,t in texts.items():
    p=Path(tempfile.mkdtemp())/"PL-ZZZZ-t.md"; p.write_text(t, newline="")
    it=parse_item(t,str(p)); f=gc.read_front_matter(p)
    print(k, "model:", it.status, it.touches, "| gc:", f.get("status"), f.get("touches"))
