#!/usr/bin/env bash
# usage: grepitems.sh <regex>  -> open items whose file matches
cd /home/user/open-anesthesia-sim
grep -liE "$1" docs/items/*.md | while read f; do st=$(grep -m1 '^status:' "$f" | awk '{print $2}'); case $st in done|dropped) ;; *) echo "$(basename $f .md | cut -c1-60) [$st]";; esac; done
