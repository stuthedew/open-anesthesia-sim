import re, sys
R="/home/user/open-anesthesia-sim"; sys.path[:0]=[R+"/tools", R+"/subprojects/docket/src"]
import main_ci_status as m
def opr(url):
    for prefix in ("git@github.com:", "ssh://git@github.com/", "https://github.com/"):
        if url.startswith(prefix):
            slug = url[len(prefix):].removesuffix(".git").strip("/")
            return slug if slug.count("/") == 1 and all(slug.split("/")) else None
    return None
def pbc(url):
    x = re.search(r"github\.com[:/]+([^/]+/[^/]+?)(?:\.git)?\s*$", url); return x.group(1) if x else None
def rcc(url):
    x = re.search(r"github\.com[:/]+(?P<slug>[^/]+/[^/]+?)(?:\.git)?/?$", url); return x.group("slug") if x else None
urls = ["https://github.com/stuthedew/open-anesthesia-sim",
 "https://github.com/stuthedew/open-anesthesia-sim.git/",
 "https://x-access-token:abc@github.com/stuthedew/open-anesthesia-sim.git",
 "ssh://git@github.com:22/stuthedew/open-anesthesia-sim.git",
 "http://local_proxy@127.0.0.1:34567/git/stuthedew/open-anesthesia-sim",
 "https://github.com/stuthedew/open-anesthesia-sim/"]
print(f"{'url':70} open_pull_requests | main_ci_status | pr_body_check | required_checks")
for u in urls: print(f"{u[:70]:70} {opr(u)} | {m.repo_slug(u)} | {pbc(u)} | {rcc(u)}")
