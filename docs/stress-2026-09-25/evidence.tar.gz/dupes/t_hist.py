import sys, subprocess
R="/home/user/open-anesthesia-sim"
sys.path[:0]=[R+"/subprojects/docket/src", R+"/tools"]
from docket import vcs
import generator_check as gc
subs = subprocess.run(["git","-C",R,"log","origin/main","--diff-filter=A","--format=%s","--","docs/items"],capture_output=True,text=True).stdout.splitlines()
def gcl(s):
    m = gc.LEADING_IDS_RE.match(s.strip()); return set(gc.ID_RE.findall(m.group(1))) if m else set()
diff=[s for s in subs if set(vcs.leading_ids(s))!=gcl(s)]
print(len(subs),"item-adding commits;",len(diff),"where leading ids differ")
for s in diff[:8]: print("  ",s[:110], "| vcs",vcs.leading_ids(s),"| gc",sorted(gcl(s)))
