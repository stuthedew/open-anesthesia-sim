import sys
R="/home/user/open-anesthesia-sim"
sys.path[:0]=[R+"/subprojects/docket/src", R+"/tools"]
from docket import vcs
import doc_check, pr_body_check
for s in ["Merge pull request #71 from stuthedew/claude/x", "PL-ABCD: title (#934)", "PL-B8HZ: title (#12) "]:
    l = vcs.Landing(commit="x", subject=s).pull_request
    f = vcs.FilingCommit(item_id="PL-B8HZ", commit="x", subject=s, paths=()).pull_request
    d = doc_check.SQUASH_PR_RE.search(s); p = pr_body_check.SQUASH_SUBJECT_RE.search(s)
    print(repr(s[:45]), "Landing:", l, "FilingCommit:", f, "doc_check:", d and d.group(1), "pr_body_check:", p and p.group(1))
