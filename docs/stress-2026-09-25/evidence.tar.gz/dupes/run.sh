#!/usr/bin/env bash
# run each read-only docket command, time it, capture output
D=/tmp/claude-0/-home-user-open-anesthesia-sim/c6060ce4-77f5-59ff-8438-bcc69ed56a56/scratchpad/dupes
R=/home/user/open-anesthesia-sim
OUT=$D/out${1:+-$1}
mkdir -p $OUT
cd $R
: > $OUT/timings.txt
run() {
  name=$1; shift
  s=$(date +%s.%N)
  "$@" > $OUT/$name.txt 2>&1
  rc=$?
  e=$(date +%s.%N)
  printf "%-22s rc=%s %6.2fs  %s\n" "$name" "$rc" "$(echo "$e - $s" | bc)" "$*" >> $OUT/timings.txt
}
run flight bin/docket flight
run flight_noremote bin/docket flight --no-remote
run next bin/docket next
run next_all bin/docket next all --limit 40
run digest bin/docket digest
run stranded_nofetch bin/docket stranded --no-fetch
run branch_nofetch bin/docket branch --no-fetch
run arm_nofetch bin/docket arm --no-fetch
run generators bin/docket generators
run status bin/docket status
run check bin/docket check
run gate bin/docket gate
run wave bin/docket wave
run list bin/docket list
run triage bin/docket triage
run concurrent bin/docket concurrent
run delegable bin/docket delegable
run milestone bin/docket milestone
run feature bin/docket feature
run trend bin/docket trend
run release_dry bin/docket release --dry-run --no-fetch
run stranded bin/docket stranded
run branch bin/docket branch
run arm bin/docket arm
run hook env CLAUDE_PROJECT_DIR=$R bash $R/.claude/hooks/docket-digest.sh
