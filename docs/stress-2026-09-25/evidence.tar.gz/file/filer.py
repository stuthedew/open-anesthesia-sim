import re, subprocess, sys, json, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from items import ITEMS, EV
REPO = pathlib.Path("/home/user/open-anesthesia-sim")
def new(feature, touches, title):
    out = subprocess.run(["bin/docket", "new", "--no-fetch", "--feature", feature, "--touches", touches, title],
                         cwd=REPO, capture_output=True, text=True)
    m = re.search(r"^(PL-[0-9A-Z]{4})\s+(\S+)$", out.stdout, re.M)
    if not m:
        sys.exit(f"new failed: {out.stdout}\n{out.stderr}")
    return m.group(1), pathlib.Path(m.group(2))
def body(path, title, problem, why, done, extra_fm=None):
    text = path.read_text()
    fm_end = text.index("\n---\n", 4) + 5
    fm = text[:fm_end]
    if extra_fm:
        fm = fm[:-4] + "".join(f"{k}: {v}\n" for k, v in extra_fm.items()) + "---\n"
    path.write_text(fm + f"\n**Problem.** {title}\n\n{problem}\n\n**Why it matters.** {why}\n\n**Done when.** {done}\n\n{EV}.\n")
filed = {}
for feature, touches, title, problem, why, done in ITEMS:
    i, p = new(feature, touches, title)
    body(p, title, problem, why, done)
    filed.setdefault(feature, []).append(i)
    print(i, feature, title[:70])
json.dump(filed, open(pathlib.Path(__file__).parent / "filed.json", "w"), indent=1)
