import json, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from filer import new, body
f = json.load(open(pathlib.Path(__file__).parent / "filed.json"))
out = {}
# impairs-generators
t = "generator_check parses a commit subject's leading ids differently from vcs.leading_ids - case-sensitive, commas only, colon required - so creation_parents misses the capturing parent of 74 of 729 item-adding commits on origin/main and the self-generation ratio it surfaces candidates from undercounts"
i, p = new("one-answer", "tools/generator_check.py, tests/unit/test_generator_check.py", t)
body(p, t,
 "Reproduced by importing both: `PL-4JHS backfill ... (#809)` gives `[PL-4JHS]` to `vcs.leading_ids` (`vcs.py:666`) and `[]` to `tools/generator_check.py:113`; `pl-b8hz: x` likewise. Over origin/main, 74 of 729 commits that add an item differ.",
 "`tools/generator_check.py` is the candidate-surfacing half of generator identification (`generator_paths`), so an undercounted parent is a cluster never surfaced - and nothing in the store says one went unfound.",
 "generator_check imports the leading-id parse from docket (or `store.ID_PATTERN` plus the same separator grammar), and a test holds both reproductions.",
 {"impairs-generators": "tools/generator_check.py's leading-id parse is case-sensitive, comma-only and colon-required where vcs.leading_ids is not, so creation_parents drops the capturing parent of 74 of 729 item-adding commits and the self-generation ratio undercounts"})
f["one-answer"].append(i); out["impairs"] = i
# regression suite
t = "Port the 2026-09-25 multi-session stress harness into subprojects/docket/tests as a regression suite: each reproduced violation a named scenario test, the seeded random interleavings behind a slow marker, and a fake forge that can say merged and closed as well as open"
i, p = new("workflow-stress-2026-09", "subprojects/docket/tests/test_multisession.py, subprojects/docket/tests/conftest.py", t)
body(p, t,
 "The harness (`harness.py` in the evidence archive, one stdlib file) builds a bare origin, a clone playing GitHub (squash-merge with `(#N)` subjects, branch deletion, closing), and N session clones, dates every commit from a world clock, and fakes pull-request state through `open_pull_requests_command`. It found eight violations across 19 scenarios and 180 seeded random steps; three were already filed (PL-X3NY, PL-QSGX, PL-WX87-adjacent). Today every one of those was found by a session stumbling on it during other work: 85% of apparatus defects filed 2026-09-15..25 were found while working another apparatus item.",
 "Class B (distributed-state inference) is 26% of apparatus defect inflow and 12 of the 35 generator heads. A defect found by CI in bulk costs one fix; the same defect found by sessions arrives as one item per session that trips it.",
 "The scenario matrix runs under `pytest` in the docket suite with each V1-V8 reproduction as a named test (xfail until its item closes), and a seeded random run is available behind a marker.")
out["suite"] = i
# heads
heads = [
 ("exact-gates", "tools/doc_check.py, subprojects/docket/src/docket/checks.py, tests/unit/test_doc_check.py, subprojects/docket/tests/test_checks.py",
  "Hard gates recognise what they check by wording - a quote near see or above, a PL- prefix, a cue word near an id - where CLAUDE.md reserves hard failure for exact rules, so each heuristic form refuses correct prose in its own way and each refusal arrives as its own item",
  ["PL-YSMV"] + f["exact-gates"],
  "live - PL-YSMV is open and the 2026-09-25 stress test reproduced 35 false refusals across 9 checks; every heuristic form still admitted to a hard gate will hand over another",
  "Whether a sentence makes the claim a hard gate checks, when the gate recognises it by wording rather than by syntax the author wrote on purpose",
  "The fuzz harness injected correct-but-tricky prose into real documents and ran each check the way `make check` does. Heuristic recognition in a hard gate produced every false refusal found. The deciding number: on all 1,647 item briefs, which doc_check has never filtered, the see/above/below citation forms matched 10 times and found 0 real stale citations; in the documents, dropping them costs 150 one-time rewrites to `§ \"X\"` and brings 264 bare `§` citations, unchecked today, under checking - 2 of them stale (PL-PCZK). 7 of doc_check's 65 commits were false-positive repairs. Google's Tricorder holds a code-review analyzer to an effective false-positive rate under 10% or it is disabled (Sadowski et al., CACM 2018).",
  "Every hard gate is an exact rule: recognition by explicit syntax (`§ \"X\"`, a front-matter field, a backticked path, the store's id grammar), with anything that needs wording to recognise demoted to an advisory; the members close or are dropped against that rule."),
 ("one-snapshot", "subprojects/docket/src/docket/vcs.py, subprojects/docket/src/docket/cli.py, subprojects/docket/src/docket/render.py, subprojects/docket/tests/test_vcs.py, subprojects/docket/tests/test_cli.py",
  "Read commands each assemble their own picture of the world - the store from the working tree, holds from refs, some after a fetch and some not, a failed fetch discarded, the forge asked by one command only - so each answers from a different moment and none says which",
  f["one-snapshot"] + ["PL-QSGX", "PL-X3NY"],
  "live - PL-QSGX and PL-X3NY are open and the 2026-09-25 simulation reproduced seven more; every new read command assembles its own picture again",
  "How fresh the refs, working tree and forge state a read command answered from are, and whether its fetch succeeded",
  "The simulation's violations V3, V4, V5, V7 and the cross-command audit's contradictions share one shape: two commands, or one command's two inputs, read different moments. `fetch_remote` swallows failure while `claiming._git` reports it; `next`/`show` read items from the working tree while holds come from refs; only `flight` asks the forge, and its contract lists open pull requests only, so merged, closed and never-opened are indistinguishable. PL-4Q9B (closed 2026-09-19) was the head for the remote-refs half, and its six members are still open.",
  "One snapshot type (fetch result, origin/main vs working tree, refs, forge states open/merged/closed or unknown) built once per command and read by every read command, each of which prints what the snapshot rests on when it is not a fresh fetch; the members close against it and the regression suite item holds them."),
 ("one-answer", "subprojects/docket/src/docket/vcs.py, tools/generator_check.py, tools/pr_body_check.py, tools/open_pull_requests.py",
  "Predicates the apparatus asks repeatedly - which ids a subject leads with, which files a branch changed, the pull-request number, the origin slug, the default ref, captures-only, how a shell command splits - are spelled again wherever they are needed, and the spellings disagree",
  f["one-answer"],
  "live - PL-FFR0 closed one on 2026-09-25 and the audit the same day reproduced seven more disagreeing pairs; each new tool copies whichever spelling it finds",
  "Which implementation of a repeated predicate is the answer, when tools, hooks and docket each spell it",
  "The audit enumerated the questions the apparatus asks and found every implementation. Nine questions have two or more that disagree on a constructed input, one of them on the protected-path audit (PL-LHPD). Four questions are already single-sourced (who holds an item, gate parity, canonical form, item id grammar) and have produced no disagreement since - which is the evidence that consolidation holds.",
  "Each listed question has one implementation that every caller imports, with `tools/` importing `subprojects/docket/src` as `branch_id_check` already does; a test per question holds the disagreeing input."),
]
for feat, touches, title, members, gen, misread, problem, done in heads:
    i, p = new(feat, touches, title)
    body(p, title, problem,
         "The members are one mechanism; fixed one at a time, each fix leaves the mechanism in place to hand over the next.", done,
         {"root-cause-of": ", ".join(members), "generator": gen, "misread": misread})
    out[feat] = i
json.dump({"filed": f, "extra": out}, open(pathlib.Path(__file__).parent / "filed2.json", "w"), indent=1)
print(json.dumps(out))
