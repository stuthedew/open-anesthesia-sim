"""Bare `§ "X"` citations in DOC_GLOBS docs and item briefs: which are reached by
any doc_check pattern, and which resolve to a heading anywhere."""
import re, sys, collections
from pathlib import Path
root = Path(sys.argv[1])
sys.path.insert(0, str(root / "tools"))
import doc_check as dc
docs = dc.read_docs(root)
every_raw = [h for t in docs.values() for h in dc._headings(t)]
# add headings of every md in tree (a § may cite a non-DOC_GLOBS file)
SEC_RE = re.compile(r'(?P<pre>.{0,40})§{1,2}\s*"(?P<q>[^"]{1,160}?)"', re.S)
def reached(text, start, end):
    for m in dc.CITATION_RE.finditer(text):
        if m.start() <= start < m.end() or start <= m.start() < end: return "CITATION_RE"
    for m in dc.QUOTED_SOURCE_RE.finditer(text):
        if m.start() <= start + 5 < m.end(): return "QUOTED_SOURCE_RE"
    return None
stats = collections.Counter(); unresolved = []
for label, sources in (("docs", docs.items()), ("items", dc._live_item_briefs(root))):
    for path, text in sources:
        for m in SEC_RE.finditer(text):
            q = dc._comparable(m.group("q")).rstrip(" .,;:")
            r = reached(text, m.start("q") - 3, m.end())
            ok = dc._cites_heading(dc._normalized(m.group("q")), every_raw)
            stats[(label, r or "unchecked", "resolves" if ok else "NO-heading")] += 1
            if not r and not ok:
                unresolved.append(f"{path}:{dc._line_of(text, m.start('q'))}: {m.group('pre')[-30:]!r} § \"{m.group('q')[:70]}\"")
for k, v in sorted(stats.items()): print(k, v)
print("\nunchecked and not a heading in any DOC_GLOBS doc (sample):")
print("\n".join(unresolved[:40])); print(len(unresolved))
