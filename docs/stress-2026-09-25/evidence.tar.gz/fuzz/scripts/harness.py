"""Inject probe paragraphs into copies of real documents, run the checks the
way `make check` invokes them, and attribute every reported line to a probe.

Usage: harness.py <repo> <probes.py>   (probes.py defines PROBES and COMMANDS)
Each probe: (probe_id, relative_file, text, kind) where kind is 'FP' (correct
content; any finding is a false positive) or 'FN' (wrong content; silence is a
false negative). The repo files are restored from a backup afterwards.
"""
import re, runpy, shutil, subprocess, sys
from pathlib import Path

repo = Path(sys.argv[1]).resolve()
spec = runpy.run_path(sys.argv[2])
PROBES, COMMANDS = spec["PROBES"], spec["COMMANDS"]

backups, spans = {}, {}
by_file = {}
for pid, rel, text, kind in PROBES:
    by_file.setdefault(rel, []).append((pid, text, kind))
for rel, probes in by_file.items():
    path = repo / rel
    original = path.read_text(encoding="utf-8") if path.exists() else None
    backups[rel] = original
    if original is None:
        pid, text, kind = probes[0]
        path.write_text(text, encoding="utf-8")
        spans[pid] = (rel, 1, text.count("\n") + 1, kind, text)
        continue
    body = original.rstrip("\n") + "\n"
    for pid, text, kind in probes:
        start = body.count("\n") + 2          # a blank line, then the probe
        body += "\n" + text.rstrip("\n") + "\n"
        end = body.count("\n")
        spans[pid] = (rel, start, end, kind, text)
    path.write_text(body, encoding="utf-8")

outputs = []
try:
    for command in COMMANDS:
        run = subprocess.run(command, cwd=repo, shell=True, capture_output=True, text=True)
        outputs.append((command, run.returncode, run.stdout + run.stderr))
finally:
    for rel, original in backups.items():
        if original is None:
            (repo / rel).unlink()
        else:
            (repo / rel).write_text(original, encoding="utf-8")

LOC = re.compile(r"(?P<file>[\w./-]+\.(?:md|py|json)):(?P<line>\d+)")
hits = {pid: [] for pid in spans}
for command, code, text in outputs:
    for line in text.splitlines():
        for pid, (rel, start, end, kind, _) in spans.items():
            if rel.startswith("docs/items/") and backups.get(rel) is None and (rel in line or rel.split("/")[-1][:7] in line):
                hits[pid].append(f"[{command.split()[0].split('/')[-1]}] {line.strip()[:260]}")
        for m in LOC.finditer(line):
            for pid, (rel, start, end, kind, _) in spans.items():
                if m.group("file") == rel and start <= int(m.group("line")) <= end:
                    hits[pid].append(f"[{command.split()[-1] if 'docket' not in command else 'docket'}] {line.strip()[:260]}")
for command, code, text in outputs:
    print(f"== {command} -> exit {code}")
print()
for pid, (rel, start, end, kind, text) in spans.items():
    found = sorted(set(hits[pid]))
    verdict = ("FALSE POSITIVE" if found else "ok (silent)") if kind == "FP" else ("caught" if found else "FALSE NEGATIVE (silent)")
    print(f"{pid} [{kind}] {rel}:{start}-{end}: {verdict}")
    print("   probe: " + text.strip().replace("\n", " / ")[:200])
    for f in found:
        print("   -> " + f)
