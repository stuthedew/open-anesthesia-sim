"""Precision of CITATION_RE on prose it has never filtered: every item brief
(open and closed), which check_citations does not read. A match that resolves
to no heading in any DOC_GLOBS doc or in the item itself is either a stale
citation or an incidental quote; listed for hand classification."""
import re, sys, collections
from pathlib import Path
root = Path(sys.argv[1]); sys.path.insert(0, str(root / "tools"))
import doc_check as dc
docs = dc.read_docs(root)
every = [h for t in docs.values() for h in dc._headings(t)]
c = collections.Counter(); rows = []
for p in sorted((root / "docs/items").glob("*.md")):
    text = p.read_text(encoding="utf-8")
    own = dc._headings(text)
    for m in dc.CITATION_RE.finditer(text):
        form = ("see" if m.group(0)[:3].lower() == "see" else "under") if m.group("named") is not None else "directed"
        term = dc._normalized(m.group("named") or m.group("directed"))
        ok = dc._cites_heading(term, every + own)
        c[(form, ok)] += 1
        if not ok: rows.append(f"{form:8} {p.name[:40]}:{dc._line_of(text, m.start())}: {' '.join(m.group(0).split())[:110]}")
print(sorted(c.items()))
print("\n".join(rows))
