W = "docs/WORKING_NOTES.md"
R = "ROADMAP.md"
M = "docs/MODEL.md"
I = "docs/items/PL-YSMV-doc-check-reads-any-quoted-string-near-the-word.md"
PROBES = [
 # ---- CITATION_RE, correct content ----
 ("C01", W, 'The run printed "documentation: 0 errors, 0 advisories" above the resident\ninstructions line, so the gate was green.', "FP"),
 ("C02", W, 'See "docket check: 0 errors" for what a clean run prints.', "FP"),
 ("C03", W, 'A session that trips it will see "cites section" in the output and go looking\nfor a heading that was never meant.', "FP"),
 ("C04", W, 'The item was filed under "housekeeping" rather than as a feature.', "FP"),
 ("C05", M, 'The halted-run banner reads "Setting refused" above the chart, in the agent\ncolour, so the refusal is next to the value it refused.', "FP"),
 ("C06", M, 'The caption "Model outputs - not measurements." below the readouts is what\nseparates a modelled value from a measured one.', "FP"),
 ("C07", W, 'A citation is written `see "Some Section"` or `"Some Section" above`, and\nthis note is about that syntax rather than a use of it.', "FP"),
 ("C08", W, '```\n$ bin/docket show PL-YSMV\nsee "Mechanism, corrected" for the reasoning\n```', "FP"),
 ("C09", W, '| run | what it printed |\n| --- | --- |\n| clean | "documentation: 0 errors" above the size line |', "FP"),
 ("C10", W, 'The Qt port is recorded in ROADMAP.md; see "Completed: v0.4.26 — the\ninterface moves to Qt" for what it carried.', "FP"),
 ("C11", W, 'See "Settled: .claude/rules/ path globs are unanchored" for the anchoring\nrule.', "FP"),
 ("C12", W, 'The old heading said "Open thread: desflurane" above; it now reads\n"Settled".', "FP"),
 ("C13", W, 'The warning text, quoted exactly, was "Setting refused — {error}" under\n"Settings", which is a label in the interface and not a heading.', "FP"),
 # ---- CITATION_RE / section citations, wrong content ----
 ("N01", W, 'The reasoning is in § "Heading That Does Not Exist Anywhere".', "FN"),
 ("N02", W, 'For the reasoning, see “Heading That Does Not Exist Anywhere”.', "FN"),
 ("N03", W, "For the reasoning, see 'Heading That Does Not Exist Anywhere'.", "FN"),
 ("N04", W, 'The reasoning is in the "Heading That Does Not Exist Anywhere" section\nabove.', "FN"),
 ("N05", W, 'The reasoning is in "Heading That Does Not Exist Anywhere" (above).', "FN"),
 ("N06", R, 'The reasoning is in § "Current baseline: v0.4.26", which the next cut\nreplaces.', "FN"),
 ("N07", W, 'The reasoning is under **Heading That Does Not Exist Anywhere** above.', "FN"),
 # ---- QUOTED_SOURCE_RE (docs, live items, docstrings) ----
 ("Q01", I, '**Proposed wording.** `CLAUDE.md`: "Hand off at 120,000 tokens of spend."\nThat sentence does not exist yet; writing it is the work.', "FP"),
 ("Q02", I, 'The wording `CLAUDE.md`, "hand off at 200,000 tokens", was replaced on\n2026-09-21 and is quoted here as history.', "FP"),
 ("Q03", W, 'Once this lands, `ROADMAP.md` "Planned milestones" gains a row for the\nnew feature.', "FP"),
 ("Q04", W, 'The sentence `CLAUDE.md` "Keep a session short" has gone; this quotes it\nfrom before the trim.', "FP"),
 # ---- code-span path existence ----
 ("P01", R, 'A future `tools/unit_suffix_check.py` would hold every float name to a\nsuffix; not built, and `PL-JW9J` carries why.', "FP"),
 ("P02", W, 'This project has no `setup.py`; `pyproject.toml` is the only build file.', "FP"),
 ("P03", W, 'The Flet chart module, `src/anesthesia_sim/app/chart_series.py`, was\ndeleted by the Qt port.', "FP"),
 ("P04", W, 'A Node project would put this in `package.json`; this one does not.', "FP"),
 ("P05", W, 'The note cites `tools/doc_chekc.py`, a typo nobody caught.', "FN"),
 ("P06", W, 'The note cites tools/doc_chekc.py without backticks.', "FN"),
 # ---- make targets ----
 ("K01", W, '```\n# make sure the virtualenv exists first\nuv sync --locked --dev\n```', "FP"),
 ("K02", W, '```\n$ make chek\nmake: *** No rule to make target \'chek\'.  Stop.\n```', "FP"),
 ("K03", W, 'Run make chek to see it fail.', "FN"),
 # ---- math delimiters (every .md) ----
 ("T01", W, 'GitHub renders escaped brackets literally, so \\[WIP\\] shows as [WIP].', "FP"),
 ("T02", W, 'The subject pattern, indented as a code block:\n\n    SQUASH_SUBJECT_RE = r"\\(#(\\d+)\\)\\s*$"', "FP"),
 ("T03", I, 'The subject pattern, indented as a code block:\n\n    SQUASH_SUBJECT_RE = r"\\(#(\\d+)\\)\\s*$"', "FP"),
 # ---- line citations (docs + live items) ----
 ("L01", I, 'A closed brief cites `tools/doc_check.py:99999`, which is past the end;\nthat stale citation is what this item is about.', "FP"),
 ("L02", W, 'The rule lives at `tools/doc_check.py:99999`.', "FN-control"),
 # ---- possessive_section_check ----
 ("S01", I, 'The rule it cites is `CLAUDE.md`\'s "Capture, always, and capture cheaply",\nquoted as the sentence it is.', "FP"),
 # ---- items are not read by CITATION_RE (PL-YSMV claim check) ----
 ("Y01", I, 'The run printed "documentation: 0 errors, 0 advisories" above the size\nline.', "FP"),
]
COMMANDS = [
 ".venv/bin/python tools/doc_check.py check",
 ".venv/bin/python tools/possessive_section_check.py",
]
