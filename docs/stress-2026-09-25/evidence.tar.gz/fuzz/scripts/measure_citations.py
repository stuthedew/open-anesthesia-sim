"""Count CITATION_RE matches per form over the documents doc_check reads.

Classifies each by (a) branch: see / under / directed-above / directed-below,
(b) whether preceded by a section-sign (i.e. already explicit `§ "X"` form),
(c) whether it resolves as a heading (_cites_heading) today.
Also counts explicit `§ "X"` occurrences in the same docs and how many of
those the check currently reaches (i.e. overlap with a CITATION_RE match).
"""
import re, sys, collections
from pathlib import Path
root = Path(sys.argv[1])
sys.path.insert(0, str(root / "tools"))
import doc_check as dc

docs = dc.read_docs(root)
headings = {p: dc._headings(t) for p, t in docs.items()}
every = [h for hs in headings.values() for h in hs]
rows = []
for path, text in docs.items():
    for m in dc.CITATION_RE.finditer(text):
        pre = text[max(0, m.start()-12):m.start()]
        if m.group("named") is not None:
            kw = re.match(r"(see|under)", m.group(0), re.I).group(1).lower()
            term = dc._normalized(m.group("named"))
            directional = dc.DIRECTION_RE.match(text[m.end():m.end()+24])
            form = kw + ("+dir" if directional else "")
            same = bool(directional)
        else:
            term = dc._normalized(m.group("directed"))
            tail = text[m.end()-6:m.end()].lower()
            form = "directed-" + ("above" if tail.endswith("above") else "below")
            same = True
        section_sign = "§" in pre[-4:]
        ok = dc._cites_heading(term, headings[path] if same else every)
        rows.append((str(path), dc._line_of(text, m.start()), form, section_sign, ok, term[:70]))

c = collections.Counter((r[2], r[3]) for r in rows)
print("matches by (form, preceded-by-§):")
for k, v in sorted(c.items()):
    print(f"  {k}: {v}")
print("total", len(rows))
# explicit § "X" occurrences in docs (not preceded by a backticked .md)
sec = 0; sec_reached = 0; sec_bare = 0
starts = {(r[0], r[1]) for r in rows}
SEC_RE = re.compile(r'(`[\w./-]+\.md`\s*)?§{1,2}\s*"([^"]{1,160}?)"', re.S)
for path, text in docs.items():
    for m in SEC_RE.finditer(text):
        sec += 1
        if not m.group(1):
            sec_bare += 1
print(f"§ \"X\" occurrences in DOC_GLOBS docs: {sec} (with a backticked doc in front: {sec - sec_bare}, bare: {sec_bare})")
out = Path(sys.argv[2]); out.write_text("\n".join("\t".join(map(str, r)) for r in rows))
