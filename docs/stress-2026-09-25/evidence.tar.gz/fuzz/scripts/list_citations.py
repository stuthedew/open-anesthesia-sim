import re, sys
from pathlib import Path
root = Path(sys.argv[1]); sys.path.insert(0, str(root / "tools"))
import doc_check as dc
docs = dc.read_docs(root)
for path, text in docs.items():
    for m in dc.CITATION_RE.finditer(text):
        pre = " ".join(text[max(0, m.start()-45):m.start()].split())
        post = " ".join(text[m.end():m.end()+12].split())
        form = ("see" if m.group(0)[:3].lower()=="see" else "under") if m.group("named") is not None else "dir"
        print(f"{form:5} {path}:{dc._line_of(text, m.start())} | ...{pre[-45:]} [[{' '.join(m.group(0).split())[:90]}]] {post}")
