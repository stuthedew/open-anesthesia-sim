W = "docs/WORKING_NOTES.md"
PROBES = [
 ("N08", W, 'The reasoning is in `CLAUDE.md` § “Heading That Does Not Exist Anywhere”.', "FN"),
 ("N09", W, 'The thread this replaced is gone; see "Status" for what it said.', "FN"),
 ("N10", W, 'The reasoning is in `CLAUDE.md` §\n"Heading That Does Not Exist Anywhere".', "FN-control"),
 ("E01", "docs/dead-ends.md", '- **Probe approach** - refuted by PL-ZZZZ, which is not an item.', "FN-control"),
 ("E02", "docs/dead-ends.md", '- **Probe approach two** - refuted, see PL-YSMV.\n> the measurement, quoted', "FP"),
]
COMMANDS = [
 ".venv/bin/python tools/doc_check.py check",
 "python3 tools/dead_ends.py check",
]
