FRONT = """---
id: {id}
title: {title}
priority: P3
effort: S
status: ready
classes: defect
touches: tools/doc_check.py
added: 2026-09-25
payoff: probe item for the false-positive audit
verify: grep -q '{marker}' tests/unit/test_doc_check.py
---

"""
PROBES = [
 # docket: capture template quoted in a fence ahead of the real sections
 ("D01", "docs/items/PL-BCD9-probe-fenced-template.md", FRONT.format(id="PL-BCD9", title="docket new wrote an empty template sessions wrote beneath", marker="probe_marker_bcd9") +
  "**Problem.** `docket new` used to write this template, and sessions wrote\nbeneath it:\n\n```\n**Why it matters.**\n\n**Done when.**\n```\n\n**Why it matters.** The empty headings are what the checker reads first.\n\n**Done when.** No new item carries the template.\n", "FP"),
 # docket: negated prerequisite in prose (advisory)
 ("D02", "docs/items/PL-BCD8-probe-negated-prerequisite.md", FRONT.format(id="PL-BCD8", title="probe negated prerequisite", marker="probe_marker_bcd8") +
  "**Problem.** This is not blocked by `PL-YSMV`; the two only share a file.\n\n**Why it matters.** Nothing waits.\n\n**Done when.** The probe is gone.\n", "FP"),
 # docket: brief in list-bullet form (sections written as bullets)
 ("D03", "docs/items/PL-BCD7-probe-bulleted-brief.md", FRONT.format(id="PL-BCD7", title="probe bulleted brief", marker="probe_marker_bcd7") +
  "- **Problem.** The brief is written as a list.\n- **Why it matters.** It still says everything.\n- **Done when.** The probe is gone.\n", "FP"),
 # fixture_id_check: .claude prose using PL- as a prefix word
 ("F01", ".claude/rules/citation-drift.md", "Every PL-prefixed token in this file is read by `tools/fixture_id_check.py`.", "FP"),
 ("F02", ".claude/skills/docket/modes/capture.md", "A commit subject leads with the id, as in `PL-XXXX: what it does`.", "FP"),
 ("F03", "tools/probe_fixture_msg.py", '"""Probe."""\n\nMESSAGE = "no PL-prefixed id leads this subject"\n', "FP"),
 # fixture / nothing: malformed and nonexistent ids in a doc outside .claude
 ("F04", "docs/WORKING_NOTES.md", "The measurement is recorded on PL-A1B2 and on PL-ZZZZ.", "FN"),
 # glyph_check: a normaliser that removes the unconfirmed glyph
 ("G01", "src/anesthesia_sim/app/probe_glyph.py", '"""Probe."""\n\nASCII_ARROWS = str.maketrans({"\\u2192": "->"})\n', "FP"),
 ("G02", "src/anesthesia_sim/app/probe_glyph2.py", '"""Probe."""\n\n\ndef change_label(old: str, new: str) -> str:\n    return f"{old} {chr(0x2192)} {new}"\n', "FN"),
]
COMMANDS = [
 "bin/docket check",
 ".venv/bin/python tools/fixture_id_check.py",
 ".venv/bin/python tools/glyph_check.py",
 ".venv/bin/python tools/doc_check.py check",
]
