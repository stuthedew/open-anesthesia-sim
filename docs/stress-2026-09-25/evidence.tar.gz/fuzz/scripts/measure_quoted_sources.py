import re, sys, collections
from pathlib import Path
root = Path(sys.argv[1]); sys.path.insert(0, str(root / "tools"))
import doc_check as dc
docs = dc.read_docs(root); declined = []
CONN = re.compile(r"`[\w./-]+\.md`[ \n]*(?P<c>" + dc.CITATION_CONNECTIVE + r")?", re.S)
c = collections.Counter(); heading = collections.Counter()
heads = {str(p): [dc._comparable(h) for h in dc._headings(t)] for p, t in docs.items()}
for path, off, text in dc._quoting_sources(root, docs, declined):
    kind = "docstring" if str(path).endswith(".py") else ("item" if "docs/items" in str(path) else "doc")
    for m in dc.QUOTED_SOURCE_RE.finditer(dc._without_fences(text)):
        cm = CONN.match(text, m.start("document") - 1)
        conn = (cm.group("c") or "bare").strip() if cm else "?"
        conn = {"'s": "possessive", "’s": "possessive"}.get(conn, conn)
        if conn.startswith("'s") or conn.startswith("’s"): conn = "possessive"
        q = dc._comparable(m.group("quoted")).rstrip(" .,;:")
        is_head = any(h == q or h.startswith(q + " ") for h in heads.get(m.group("document"), []))
        c[(conn, kind)] += 1
        heading[(conn, "names-a-heading" if is_head else "sentence/other")] += 1
tot = collections.Counter()
for (conn, kind), n in c.items(): tot[conn] += n
print("QUOTED_SOURCE_RE matches by connective:", dict(tot.most_common()))
print("by connective x source:", sorted(c.items()))
print("heading vs sentence:", sorted(heading.items()))
