#!/bin/sh
# Two probes the append-harness cannot express: a row inside MODEL.md's Symbols
# table (core_vocabulary_check), and branch names / subjects carrying an
# id-shaped word (branch_id_check). Run from the scratch repo; restores state.
set -u
cp docs/MODEL.md /tmp/MODEL.md.probe.bak
sed -i '725a | $`\\lvert F_A \\rvert`$ written as $`\\|F_A\\|`$ | Alveolar agent fraction magnitude | dimensionless | `AlveolarCompartment.partial_pressure_fraction` |' docs/MODEL.md
echo "== core_vocabulary_check with an escaped pipe in a Symbol cell"; .venv/bin/python tools/core_vocabulary_check.py; echo "rc=$?"
cp /tmp/MODEL.md.probe.bak docs/MODEL.md
start=$(git branch --show-current)
git checkout -q -b claude/pl-ctrl-hotkeys && echo probe > probe.txt && git add probe.txt && git -c user.email=p@p -c user.name=probe commit -q -m "Add keyboard shortcuts"
echo "== branch_id_check on claude/pl-ctrl-hotkeys (no item PL-CTRL exists)"; python3 tools/branch_id_check.py; echo "rc=$?"
git checkout -q -b claude/hotkeys-x && git -c user.email=p@p -c user.name=probe commit -q --amend -m "PL-HTML export: write the run as a page"
echo "== branch_id_check with subject 'PL-HTML export: ...' (no item PL-HTML exists)"; python3 tools/branch_id_check.py; echo "rc=$?"
git checkout -q "$start" && git branch -D -q claude/pl-ctrl-hotkeys claude/hotkeys-x
