import re, sys, collections
from pathlib import Path
root = Path(sys.argv[1]); sys.path.insert(0, str(root / "tools"))
import doc_check as dc
docs = dc.read_docs(root)
span = fence = 0; names = collections.Counter()
for path, text in docs.items():
    for m in dc.CODE_SPAN_RE.finditer(text):
        for mm in dc.MAKE_MENTION_RE.finditer(m.group(1)): span += 1; names[mm.group("name")] += 1
    for start, body in dc._fenced_blocks(text):
        for line in body:
            for mm in dc.MAKE_MENTION_RE.finditer(line): fence += 1; names[mm.group("name")] += 1
print(f"make mentions: {span} in code spans, {fence} in fences; names: {dict(names)}")
# code-span path citations
n = 0; kinds = collections.Counter()
for path, text in docs.items():
    for m in dc.CODE_SPAN_RE.finditer(text):
        if dc._is_path_citation(m.group(1)): n += 1
print("code-span path citations in DOC_GLOBS docs:", n)
# math: every .md; TEX delimiters/edges found today = 0 (clean). count $`..`$ spans
spans = 0
for p in root.rglob("*.md"):
    if any(x in p.parts for x in (".venv", ".git")): continue
    spans += len(dc.MATH_SPAN_RE.findall(p.read_text(encoding="utf-8", errors="replace")))
print("well-formed inline math spans across all .md:", spans)
# line citations
lc = 0
for path, text in list(docs.items()) + list(dc._live_item_briefs(root)):
    lc += sum(1 for m in dc.LINE_CITATION_RE.finditer(dc._without_fences(text)) if dc._is_path_citation(m.group(1)))
print("line citations (docs + live items):", lc)
