"""For each target, walk the commits touching it, resolve every item id in the
subject to its title, and count titles describing a false positive (the check
refusing/reading correct content). Prints the matching titles for audit."""
import re, subprocess, sys
from pathlib import Path
root = Path(sys.argv[1])
titles = {}
for p in (root / "docs/items").glob("*.md"):
    head = p.read_text(encoding="utf-8")[:1500]
    i = re.search(r"^id:\s*(\S+)", head, re.M); t = re.search(r"^title:\s*(.+)$", head, re.M)
    if i and t: titles[i.group(1)] = t.group(1)
FP = re.compile(r"misread|mis-read|\breads? (?:an?|any|the|every|each|its|one)?\b[^.;]{0,80}? as (?:an?|the)?\b|false (?:error|positive|fire|alarm)|refuses? (?:correct|a correct|prose|text that)|fires on|over-?reach|hard-?fails|spurious|mistakes?\b|wrongly (?:fail|refus|report|flag)|flags? correct|rewor", re.I)
NAMES = {
 "tools/doc_check.py": r"doc_check|doc-check|CITATION_RE|citation|math|make target|QUOTED_SOURCE",
 "tools/possessive_section_check.py": r"possessive",
 "tools/core_vocabulary_check.py": r"core_vocabulary|vocabulary|Symbols",
 "tools/glyph_check.py": r"glyph",
 "tools/pr_body_check.py": r"pr_body|body",
 "tools/pr_title_check.py": r"pr_title|title",
 "tools/branch_id_check.py": r"branch_id|branch-id|branch",
 "tools/agent_identity_check.py": r"agent_identity|identity|disabled",
 "tools/fixture_id_check.py": r"fixture",
 "tools/rules_paths_check.py": r"rules_paths|paths",
 "tools/dead_ends.py": r"dead.ends",
 "subprojects/docket/src/docket/checks.py": r"check|brief|prose|recommend|section|advisory|prerequisite|thread",
}
for f, name in NAMES.items():
    subs = subprocess.run(["git", "log", "--format=%h %s", "--follow", "--", f], cwd=root, capture_output=True, text=True).stdout.splitlines()
    ids = set(); hits = []
    for line in subs:
        sha, _, subject = line.partition(" ")
        lead = re.match(r"^((?:PL-[0-9A-Z]{3,4}(?:,\s*|\s+and\s+|\s*&\s*)?)+)", subject)
        for i in re.findall(r"PL-[0-9A-Z]{3,4}", lead.group(1) if lead else ""):
            ids.add(i)
            t = titles.get(i, "")
            if FP.search(t) and re.search(name, t, re.I):
                hits.append(f"    {sha} {i}: {t[:150]}")
    print(f"{f}: {len(subs)} commits, {len(ids)} item ids; FP-describing titles: {len(set(hits))}")
    print("\n".join(sorted(set(hits))))
